package cucumberTest;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class GenericMethods {
	protected int Exp_memberId,Exp_role, i, Exp_quoteReference;
	protected String Exp_title,Exp_firstName,Exp_lastName,Exp_dob,Exp_email,Exp_mob;
	protected boolean Exp_EV,Exp_MV,Exp_AQ;
	protected String Exp_addressLine, Exp_postcode, Exp_productType, Exp_mpans, Exp_mprns, Exp_quoteReason,Exp_tariffName, Exp_expiryDateTime, Exp_comparisionSupplier;
	protected double Exp_savingAmountGBP, Exp_annualQuoteAmountGBP, Exp_minAnnualQuoteAmountGBP, Exp_carbonSavingskg, Exp_elecAnnualUsagekWhs, Exp_elecUnitRate, Exp_elecAnnualAmounIncMFGBP, Exp_elecAnnualAmountExcMFGBP, Exp_elecMonthlyMembershipFeeGBP, Exp_elecAnnualMembershipFeeGBP;
	protected double Exp_gasAnnualUsagekWhs, Exp_gasUnitRate, Exp_gasAnnualAmountIncMFGBP, Exp_gasAnnualAmountExcMFGBP, Exp_gasMonthlyMembershipFeeGBP, Exp_gasAnnualMembershipFeeGBP;

	//get current date timestamp

	public static String date()
	{
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		Date d = new Date();
		String date = df.format(d);
		return date;
		/*DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now)); //2016/11/16 12:08:43
		String date = dtf.format(now);
		return date;*/
	}


	// read data from excel sheet
	//1) get string values

	public String getStringValues(String path, String sheetName, int row, int cell)
	{
		String retval = null;
		try 
		{
			FileInputStream fis = new FileInputStream(path);
			Workbook wb = WorkbookFactory.create(fis);
			Sheet sh  = wb.getSheet(sheetName);
			Row r = sh.getRow(row);
			Cell cel = r.getCell(cell);
			retval = cel.toString();
		}
		catch (Exception e) 
		{	
			e.printStackTrace();
		}
		return retval;
	}
	//2) get int values
	public int getIntValues(String path, String sheetName, int row, int cell)
	{
		int retval = 0;

		try
		{
			FileInputStream fis = new FileInputStream(path);
			Workbook wb = WorkbookFactory.create(fis);
			Sheet sh  = wb.getSheet(sheetName);
			Row r = sh.getRow(row);
			Cell cel = r.getCell(cell);
			String data = cel.toString();
			retval = Integer.parseInt(data);
			

			//System.out.println("data: "+data);
			//convert string to float
			//float retval1 = Float.parseFloat(data);
			//System.out.println("float: "+retval1);
			//convert float to integer
			//retval = (int) (retval1);
			//System.out.println("retVal: "+ retval);

		}
		catch (Exception e) 
		{	
			e.printStackTrace();
		}
		System.out.println("retval "+ retval);
		return retval;
	}
	//3) get boolean values
	public boolean getBooleanValues(String path, String sheetName, int row, int cell)
	{
		boolean retval = false;
		try
		{
			FileInputStream fis = new FileInputStream(path);
			Workbook wb = WorkbookFactory.create(fis);
			Sheet sh  = wb.getSheet(sheetName);
			Row r = sh.getRow(row);
			Cell cel = r.getCell(cell);
			String data = cel.toString();
			retval = Boolean.parseBoolean(data);
		}
		catch (Exception e) 
		{	
			e.printStackTrace();
		}
		return retval;
	}

	//4) get double values
	public double getDoubleValues(String path, String sheetName, int row, int cell)
	{
		double retval = 0.0;
		try 
		{
			FileInputStream fis  = new FileInputStream(path);
			Workbook wb = WorkbookFactory.create(fis);
			Sheet sh = wb.getSheet(sheetName);
			Row r = sh.getRow(row);
			Cell cel = r.getCell(cell);
			String data = cel.toString();
			retval = Double.parseDouble(data);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}


		return retval;
	}

	//fetch verification code from log

	public String getVerificationCode(String path)
	{
		String retval = null;

		FileReader fr;
		double count = 0;
		try 
		{
			fr = new FileReader(path);
			BufferedReader br = new BufferedReader(fr);
			String inputSearch = "postMemberIdentityEmailLoginJanrainVerifyMemberIdentityResponse";
			String line = "";
			StringBuilder sb = new StringBuilder();
			String afterReplacement = null;
			while ((line = br.readLine()) != null) 
			{
				//System.out.println(br.readLine());
				String[] words = line.split(" ");

				for (String word : words) {
					if (word.equals(inputSearch)) 
					{
						System.out.println();
						count++;
						if (count >= 1) 
						{
							sb.append(line);
							sb.append("\n");
							//System.out.println(sb.toString());
							//System.out.println("length of sb: "+sb.length());
							String[] v1 = sb.toString().split(",");

							String[] v2 = v1[6].split(":");
							//System.out.println(""+v2[1]);
							line = br.readLine();
							afterReplacement = v2[1].replace("\"", "");
							//System.out.println("afterReplacement: "+afterReplacement);
							sb.delete(0, sb.length());
							//System.out.println("sb after deleting: "+sb.toString()+":");

						}
					}
				}
			}
			retval = afterReplacement;
			fr.close();
		}
		catch (Exception e1) 
		{
			e1.printStackTrace();
		}

		return retval;
	}
	
	
}
