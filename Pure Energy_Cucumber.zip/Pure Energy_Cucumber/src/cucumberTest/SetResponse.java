package cucumberTest;

public class SetResponse extends GenericMethods
{


	//set expected response
	//1) User Profile

	public void setExpectedResponseUP(String path, String sheetName, int row)
	{
		Exp_memberId = getIntValues(path, sheetName, row, 0);
		Exp_title = getStringValues(path, sheetName, row, 1);
		Exp_firstName = getStringValues(path, sheetName, row, 2);
		Exp_lastName = getStringValues(path,sheetName, row, 3);
		Exp_dob = getStringValues(path, sheetName, row, 4);
		Exp_email = getStringValues(path, sheetName, row, 5);
		Exp_mob = getStringValues(path, sheetName, row, 6);
		Exp_EV = getBooleanValues(path, sheetName, row, 7);
		Exp_MV = getBooleanValues(path, sheetName, row, 8);
		Exp_role = getIntValues(path, sheetName, row, 9);
		Exp_AQ = getBooleanValues(path, sheetName, row, 10);

		//print expected values
		System.out.println("Expected Response parameters are: ");
		System.out.println("memberId: "+Exp_memberId);
		System.out.println("title: "+Exp_title);
		System.out.println("firstName: "+Exp_firstName);
		System.out.println("lastName: "+Exp_lastName);
		System.out.println("dateOfBirth: "+Exp_dob);
		System.out.println("email: "+Exp_email);
		System.out.println("mobileNo: "+Exp_mob);
		System.out.println("emailVerified: "+Exp_EV);
		System.out.println("mobileVerified: "+Exp_MV);
		System.out.println("role: "+Exp_role);
		System.out.println("activeQuote: "+Exp_AQ);
		System.out.println();

	}

	//2) Member Identity GET

	public  void setExpectedResponse_MI_Get(String path, String sheetName, int row)
	{
		Exp_memberId = getIntValues(path, sheetName, row, 0);
		Exp_title = getStringValues(path, sheetName, row, 1);
		Exp_firstName = getStringValues(path, sheetName, row, 2);
		Exp_lastName = getStringValues(path,sheetName, row, 3);
		Exp_dob = getStringValues(path, sheetName, row, 4);
		Exp_email = getStringValues(path, sheetName, row, 5);
		Exp_mob = getStringValues(path, sheetName, row, 6);
		Exp_EV = getBooleanValues(path, sheetName, row, 7);
		Exp_MV = getBooleanValues(path, sheetName, row, 8);

		//print expected values
		System.out.println("Expected Response parameters are: ");
		System.out.println("memberId: "+Exp_memberId);
		System.out.println("title: "+Exp_title);
		System.out.println("firstName: "+Exp_firstName);
		System.out.println("lastName: "+Exp_lastName);
		System.out.println("dateOfBirth: "+Exp_dob);
		System.out.println("email: "+Exp_email);
		System.out.println("mobileNo: "+Exp_mob);
		System.out.println("emailVerified: "+Exp_EV);
		System.out.println("mobileVerified: "+Exp_MV);
	}

	// 3) Member Identity POST

	public void setExpectedResponse_MI_POST(String title, String firstName, String lastName, String email, String mobile, String dateOfBirth)
	{
		Exp_title = title;
		Exp_firstName = firstName;
		Exp_lastName = lastName;
		Exp_email  = email;
		Exp_mob = mobile;
		Exp_dob = dateOfBirth;
	}

	// 4) Member Identity PUT

	public void setExpectedResponse_MI_PUT(int memberId,String title, String firstName, String lastName, String email, String mobile, String dateOfBirth)
	{
		Exp_memberId = memberId;
		Exp_title = title;
		Exp_firstName = firstName;
		Exp_lastName = lastName;
		Exp_email  = email;
		Exp_mob = mobile;
		Exp_dob = dateOfBirth;
	}

	// 5) Retrieve Quotes

	public void setExpectedResponse_Retrieve_Quotes(String path, String sheetName, int row)
	{
		Exp_memberId = getIntValues(path, sheetName, row, 0);
		Exp_addressLine = getStringValues(path, sheetName, row, 1);
		Exp_postcode = getStringValues(path, sheetName, row, 2) ;
		Exp_productType = getStringValues(path, sheetName, row, 3);
		Exp_mpans = getStringValues(path, sheetName, row, 4);
		Exp_mprns = getStringValues(path, sheetName, row, 5);
		Exp_quoteReason = getStringValues(path, sheetName, row, 6);
		Exp_quoteReference = getIntValues(path, sheetName, row, 7);
		Exp_tariffName = getStringValues(path, sheetName, row, 8);
		Exp_savingAmountGBP = getDoubleValues(path, sheetName, row, 9);
		Exp_carbonSavingskg = getDoubleValues(path, sheetName, row, 10);
		Exp_annualQuoteAmountGBP = getDoubleValues(path, sheetName, row, 11);
		Exp_minAnnualQuoteAmountGBP = getDoubleValues(path, sheetName, row, 12);
		Exp_comparisionSupplier = getStringValues(path, sheetName, row, 13);
		Exp_elecAnnualUsagekWhs = getDoubleValues(path, sheetName, row, 14);
		Exp_elecUnitRate = getDoubleValues(path, sheetName, row, 15);
		Exp_elecAnnualAmounIncMFGBP = getDoubleValues(path, sheetName, row, 16);
		Exp_elecAnnualAmountExcMFGBP = getDoubleValues(path, sheetName, row, 17);
		Exp_elecMonthlyMembershipFeeGBP = getDoubleValues(path, sheetName, row, 18);
		Exp_elecAnnualMembershipFeeGBP = getDoubleValues(path, sheetName, row, 19);
		Exp_gasAnnualUsagekWhs = getDoubleValues(path, sheetName, row, 20);
		Exp_gasUnitRate = getDoubleValues(path, sheetName, row, 21);
		Exp_gasAnnualAmountIncMFGBP = getDoubleValues(path, sheetName, row, 22);
		Exp_gasAnnualAmountExcMFGBP = getDoubleValues(path, sheetName, row, 23);
		Exp_gasMonthlyMembershipFeeGBP = getDoubleValues(path, sheetName, row, 24);
		Exp_gasAnnualMembershipFeeGBP = getDoubleValues(path, sheetName, row, 25);
		Exp_expiryDateTime = getStringValues(path, sheetName, row, 26);
		
	}
	
	// Quotes
	
	
}
