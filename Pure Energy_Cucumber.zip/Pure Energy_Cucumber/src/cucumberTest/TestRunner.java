package cucumberTest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
 
@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature/Dev/UserProfile.feature",
		glue={"stepDefinition"},
				format = { "pretty",
				"html:target/cucumber-html-reports",
				"json:target/cucumber.json"},
		//plugin = {"pretty","html:target/cucumber-reports"}
		tags = {"@Execute"}
		//monochrome = true
		
		)
/*
@CucumberOptions(
tags = {"~@Ignore"},
format = { "pretty",
"html:target/cucumber-html-reports",
"json:target/cucumber.json"}*/
public class TestRunner {

}
