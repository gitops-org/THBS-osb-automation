package stepDefinition;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Properties;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import responseComparision.GET_Psr;
import responseComparision.MI_GET;
import responseComparision.MI_POST;
import responseComparision.MI_PUT;
import responseComparision.RetrieveQuotes;
import responseComparision.UserProfile;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumberTest.GenericMethods;

public class TestSteps
{
	private Response response;
	private RequestSpecification req;
	private String FinalUrl;
	private int memberId,i, Act_memberId,respStatusCode, Act_quoteReference;
	private String firstName, lastName, title, email, mobile, dob, refCode, refSource, refEmail,API_name;
	private String Act_title,Act_firstName,Act_lastName,Act_dob,Act_email, Act_mobileNo;
	private boolean Act_emailVerified, Act_mobileVerified;
	private String postCode, Act_postcode;
	private String Act_addressLine, Act_productType, Act_mpans, Act_mprns, Act_quoteReason, Act_tariffName, Act_comparisonSupplier, Act_expiryDateTime;
	private double Act_savingAmountGBP, Act_carbonSavingskg, Act_annualQuoteAmountGBP, Act_minAnnualQuoteAmountGBP, Act_elecAnnualUsagekWhs, Act_elecUnitRate, Act_elecAnnualAmounIncMFGBP, Act_elecAnnualAmountExcMFGBP, Act_elecMonthlyMembershipFeeGBP,Act_elecAnnualMembershipFeeGBP, Act_gasAnnualUsagekWhs, Act_gasUnitRate, Act_gasAnnualAmountIncMFGBP, Act_gasAnnualAmountExcMFGBP, Act_gasMonthlyMembershipFeeGBP, Act_gasAnnualMembershipFeeGBP;
	public String reason="_";
	public String Device_Advertising_ID, Device_Notification_ID, Device_Type, Client_Id, Pure_Tracking_Id;
	GenericMethods gm = new GenericMethods();
	JSONObject requestParams = new JSONObject();
	
	InputStream is = null;

	//fetch the values from property file
	public String getProp(String arg) throws Exception
	{
		Properties p = new Properties();
		is = p.getClass().getResourceAsStream("/prop.properties");
		p.load(is);
		return p.getProperty(arg);
		
	}


	@Given("^a member exists with memberId of (\\d+)$")
	public void a_member_exists_with_memberId_of(int memberId) throws Throwable {
		req = given().param("memberId:" + memberId);
		this.memberId = memberId;

	}

	@Given("^the request url is \"([^\"]*)\"$")
	public void the_request_url_is(String url) throws Throwable 
	{
		FinalUrl = url;
		//FinalUrl = url.concat("/"+memberId);
		//System.out.println(memberId);
		System.out.println("final url: "+FinalUrl);
	}

	@Given("^the API to be executed is \"([^\"]*)\"$")
	public void the_API_to_be_executed_is(String API_name) throws Throwable 
	{
		this.API_name = API_name;

		switch (API_name) 
		{
		case "Address":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Address")+API_name+"_"+GenericMethods.date()+"_"+postCode+".txt")));
			break;

		case "Get Meter Reading":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Get_Meter_Reading")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "Bills Usage Summary":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Bills_Usage_Summary")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "Get PSR":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Get_PSR")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "Accounts":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Accounts")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "MI_GET":
			System.setOut(new PrintStream(new FileOutputStream(getProp("MI_GET")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "Retrieve Quotes":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Retrieve_Quotes")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "User Profile":
			System.setOut(new PrintStream(new FileOutputStream(getProp("User_Profile")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "Bank Account Validation":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Bank_Account_Validation")+API_name+"_"+GenericMethods.date()+".txt")));
			break;

		case "Case":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Case")+API_name+"_"+GenericMethods.date()+".txt")));
			break;

		case "Complaints":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Complaints")+API_name+"_"+GenericMethods.date()+".txt")));
			break;

		case "Customer Enquiry":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Customer_Enquiry")+API_name+"_"+GenericMethods.date()+"_"+reason+".txt")));
			break;

		case "POST Meter Reading":
			System.setOut(new PrintStream(new FileOutputStream(getProp("POST_Meter_Reading")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "Validate Meter Reading":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Validate_Meter_Reading")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;	

		case "Cancel Switch":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Cancel_Switch")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;	

		case "MI_Create":
			System.setOut(new PrintStream(new FileOutputStream(getProp("MI_Create")+API_name+"_"+GenericMethods.date()+"_"+email+".txt")));
			break;

		case "MI_Login":
			System.setOut(new PrintStream(new FileOutputStream(getProp("MI_Login")+API_name+"_"+GenericMethods.date()+".txt")));
			break;	

		case "MI_Verify":
			System.setOut(new PrintStream(new FileOutputStream(getProp("MI_Verify")+API_name+"_"+GenericMethods.date()+".txt")));
			break;	

		case "MI_Type":
			System.setOut(new PrintStream(new FileOutputStream(getProp("MI_Type")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;	

		case "Provision Energy Member":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Provision_Energy_Member")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;	

		case "Quick Quotes":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Quick_Quotes")+API_name+"_"+GenericMethods.date()+"_"+email+".txt")));
			break;

		case "Quotes":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Quotes")+API_name+"_"+GenericMethods.date()+".txt")));
			break;	

		case "Save Quotes":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Save_Quotes")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;	

		case "Update Phone Number":
			System.setOut(new PrintStream(new FileOutputStream(getProp("Update_Phone_Number")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;	

		case "MI_Update":
			System.setOut(new PrintStream(new FileOutputStream(getProp("MI_Update")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;	

		case "MI_Update Links":
			System.setOut(new PrintStream(new FileOutputStream(getProp("MI_Update_Links")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;	

		case "PUT Direct Debit Date":
			System.setOut(new PrintStream(new FileOutputStream(getProp("PUT_Direct_Debit_Date")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "MI_Quotes":
			System.setOut(new PrintStream(new FileOutputStream(getProp("MI_Quotes")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		case "POST PSR":
			System.setOut(new PrintStream(new FileOutputStream(getProp("POST_PSR")+API_name+"_"+GenericMethods.date()+"_"+memberId+".txt")));
			break;

		default:
			break;
		}

		//System.setOut(new PrintStream(new FileOutputStream("D:/Apoorva/Pure Energy/RRL/eclipse responses/"+API_name+"_"+GenericMethods.date()+"_"+memberId+reason+".txt")));
	}

	@When("^a member retrieves the details by memberId$")
	public void a_member_retrieves_the_details_by_memberId() throws Throwable {
		//pass header parameters
		if ("App".equals(Client_Id)) 
		{
			req.header("Content-Type","application/json");
			req.header("Device-Advertising-ID",Device_Advertising_ID);
			req.header("Device-Notification-ID",Device_Notification_ID);
			req.header("Device-Type",Device_Type);
			req.header("Client-Id",Client_Id);
			req.header("Pure-Tracking-Id",Pure_Tracking_Id);
		}
		else 
		{
			req.header("Content-Type","application/json");
			req.header("Client-Id",Client_Id);
			req.header("Pure-Tracking-Id",Pure_Tracking_Id);
		}

		response = req.relaxedHTTPSValidation().get(FinalUrl);
		//response = request.get(FinalUrl);
		//ResponseBody body = response.getBody();

		//body.prettyPrint();
		//print the response
		response.prettyPrint();
		System.out.println();

	}

	@Then("^the status code should be (\\d+)$")
	public void the_status_code_should_be(int statusCode) throws Throwable 
	{

		respStatusCode =  response.getStatusCode();
		if(statusCode == respStatusCode)
		{
			System.out.println("Status code returned is expected");

		}
		else
		{
			System.out.println("Status code returned is not expected");

		}

	}

	@Given("^the header parameters Device-Advertising-ID, Device-Notification-ID, Device-Type, Client-Id and Pure-Tracking-Id as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void the_header_parameters_Device_Advertising_ID_Device_Notification_ID_Device_Type_Client_Id_and_Pure_Tracking_Id_as(String Device_Advertising_ID, String Device_Notification_ID, String Device_Type, String Client_Id, String Pure_Tracking_Id) throws Throwable 
	{
		this.Device_Advertising_ID = Device_Advertising_ID;
		this.Device_Notification_ID = Device_Notification_ID;
		this.Device_Type = Device_Type;
		this.Client_Id = Client_Id;
		this.Pure_Tracking_Id = Pure_Tracking_Id;
	}

	@Given("^the header parameters Client-Id and Pure-Tracking-Id as \"([^\"]*)\",\"([^\"]*)\"$")
	public void the_header_parameters_Client_Id_and_Pure_Tracking_Id_as(String Client_Id, String Pure_Tracking_Id) throws Throwable 
	{
		this.Client_Id = Client_Id;
		this.Pure_Tracking_Id = Pure_Tracking_Id;
	}


	@SuppressWarnings("unused")
	@Then("^response parameters of \"([^\"]*)\" should be verified$")
	public void response_parameters_of_should_be_verified(String API_name) throws Throwable 
	{
		if (API_name.equals("MemberIdentity_GET")) 
		{
			MI_GET g = new MI_GET();
			if (respStatusCode == 200) 
			{
				Act_memberId = response.jsonPath().getInt("memberId");
				Act_title = response.jsonPath().getString("title");
				Act_firstName = response.jsonPath().getString("firstName");
				Act_lastName = response.jsonPath().getString("lastName");
				Act_dob = response.jsonPath().getString("dateOfBirth");
				Act_email = response.jsonPath().getString("email");
				Act_mobileNo = response.jsonPath().getString("mobileNo");
				Act_emailVerified = response.jsonPath().getBoolean("emailVerified");
				Act_mobileVerified = response.jsonPath().getBoolean("mobileVerified");

				switch (memberId) {
				case 79106:
					i = 1;
					g.setExpectedResponse(getProp("Expected_Response"), "MI_GET", i); 
					break;
				case 70401:
					i = 2;
					g.setExpectedResponse(getProp("Expected_Response"), "MI_GET", i); 
					break;
				case 56196:
					i = 3;
					g.setExpectedResponse(getProp("Expected_Response"), "MI_GET", i); 
					break;		
				default:
					break;

				}

				g.compareResponse(Act_memberId, Act_title, Act_firstName, Act_lastName, Act_dob, Act_email, Act_mobileNo, Act_emailVerified, Act_mobileVerified);

			}
		}
		else if (API_name.equals("UserProfile")) 
		{
			UserProfile up = new UserProfile();
			if (respStatusCode ==200) 
			{
				
				Act_memberId = response.jsonPath().getInt("memberId");
				Act_title = response.jsonPath().getString("title");
				Act_firstName = response.jsonPath().getString("firstName");
				Act_lastName = response.jsonPath().getString("lastName");
				Act_dob = response.jsonPath().getString("dateOfBirth");
				Act_email = response.jsonPath().getString("email");
				Act_mobileNo = response.jsonPath().getString("mobileNo");
				Act_emailVerified = response.jsonPath().getBoolean("emailVerified");
				Act_mobileVerified = response.jsonPath().getBoolean("mobileVerified");
				int Act_role = response.jsonPath().getInt("role");
				boolean Act_activeQuote = response.jsonPath().getBoolean("activeQuote");

				System.out.println();	

				switch (memberId) {
				case 44420:
					i = 1;
					up.setExpectedResponse(getProp("Expected_Response"), "UserProfile", i); 
					break;
				case 49921:
					i = 2;
					up.setExpectedResponse(getProp("Expected_Response"), "UserProfile", i); 
					break;
				case 48897:
					i = 3;
					up.setExpectedResponse(getProp("Expected_Response"), "UserProfile", i); 
					break;
				case 67969:
					i = 4;
					up.setExpectedResponse(getProp("Expected_Response"), "UserProfile", i);
					break;
				case 65793:
					i = 5;
					up.setExpectedResponse(getProp("Expected_Response"), "UserProfile", i);
					break;
				case 33025:
					i = 6;
					up.setExpectedResponse(getProp("Expected_Response"), "UserProfile", i);
					break;
				case 76932:
					i = 7;
					up.setExpectedResponse(getProp("Expected_Response"), "UserProfile", i);
					break;
				case 102273:
					i = 8;
					up.setExpectedResponse(getProp("Expected_Response"), "UserProfile", i);
					
				default:
					break;

				}

				up.compareResponse(Act_memberId, Act_title, Act_firstName, Act_lastName, Act_dob, Act_email, Act_mobileNo, Act_emailVerified, Act_mobileVerified, Act_role, Act_activeQuote);

				//copy response to a text file
				//System.setOut(new PrintStream(new FileOutputStream("D:/Apoorva/Pure Energy/RRL/eclipse responses/UserProfile/userProfile_"+GenericMethods.date()+"_"+memberId+".txt")));
				
			}


		}

		else if (API_name.equals("MemberIdentity_POST")) 
		{
			MI_POST po = new MI_POST();
			if (respStatusCode == 200) 
			{
				Act_memberId = response.jsonPath().getInt("memberId");
				Act_title = response.jsonPath().getString("title");
				Act_firstName = response.jsonPath().getString("firstName");
				Act_lastName = response.jsonPath().getString("lastName");
				Act_dob = response.jsonPath().getString("dateOfBirth");
				Act_email = response.jsonPath().getString("email");
				Act_mobileNo = response.jsonPath().getString("mobileNo");
				po.setExpectedResponse(title, firstName, lastName, email, mobile, dob);
				po.compareResponse(Act_title, Act_firstName, Act_lastName, Act_dob, Act_email, Act_mobileNo);
			}
		}

		else if (API_name.equals("MemberIdentity_PUT")) 
		{
			MI_PUT pu = new MI_PUT();
			if (respStatusCode == 200) 
			{
				Act_memberId = response.jsonPath().getInt("memberId");
				Act_title = response.jsonPath().getString("title");
				Act_firstName = response.jsonPath().getString("firstName");
				Act_lastName = response.jsonPath().getString("lastName");
				Act_dob = response.jsonPath().getString("dateOfBirth");
				Act_email = response.jsonPath().getString("email");
				Act_mobileNo = response.jsonPath().getString("mobileNo");

				pu.setExpectedResponse(memberId, title, firstName, lastName, email, mobile, dob);
				pu.compareResponse(Act_memberId, Act_title, Act_firstName, Act_lastName, Act_email, Act_mobileNo, Act_dob);
			}
		}
		else if (API_name.equals("Retrieve_Quotes")) 
		{
			RetrieveQuotes rq = new RetrieveQuotes();
			if (respStatusCode == 200) 
			{
				//System.out.println("entering if loop");
				Act_memberId = response.jsonPath().getInt("memberId");
				Act_addressLine = response.jsonPath().getString("addressLine");
				Act_postcode = response.jsonPath().getString("postcode");
				Act_productType = response.jsonPath().getString("productType");
				Act_mpans = response.jsonPath().getString("mpans");
				Act_mprns = response.jsonPath().getString("mprns");
				Act_quoteReason = response.jsonPath().getString("quoteReason");
				Act_quoteReference = response.jsonPath().getInt("quoteReference");
				Act_tariffName = response.jsonPath().getString("tariffName");
				Act_savingAmountGBP = response.jsonPath().getDouble("savingAmountGBP");
				Act_carbonSavingskg = response.jsonPath().getDouble("carbonSavingskg");
				Act_annualQuoteAmountGBP = response.jsonPath().getDouble("annualQuoteAmountGBP");
				Act_minAnnualQuoteAmountGBP = response.jsonPath().getDouble("minAnnualQuoteAmountGBP");
				Act_comparisonSupplier = response.jsonPath().getString("comparisonSupplier");
				Act_elecAnnualUsagekWhs = response.jsonPath().getDouble("elecAnnualUsagekWhs");
				Act_elecUnitRate = response.jsonPath().getDouble("elecUnitRate");
				Act_elecAnnualAmounIncMFGBP = response.jsonPath().getDouble("elecAnnualAmounIncMFGBP");
				Act_elecAnnualAmountExcMFGBP = response.jsonPath().getDouble("elecAnnualAmountExcMFGBP");
				Act_elecMonthlyMembershipFeeGBP = response.jsonPath().getDouble("elecMonthlyMembershipFeeGBP");
				Act_elecAnnualMembershipFeeGBP = response.jsonPath().getDouble("elecAnnualMembershipFeeGBP");
				if (Act_productType.equalsIgnoreCase("Dual")) 
				{
					Act_gasAnnualUsagekWhs = response.jsonPath().getDouble("gasAnnualUsagekWhs");
					Act_gasUnitRate = response.jsonPath().getDouble("gasUnitRate");
					Act_gasAnnualAmountIncMFGBP = response.jsonPath().getDouble("gasAnnualAmountIncMFGBP");
					Act_gasAnnualAmountExcMFGBP = response.jsonPath().getDouble("gasAnnualAmountExcMFGBP");
					Act_gasMonthlyMembershipFeeGBP = response.jsonPath().getDouble("gasMonthlyMembershipFeeGBP");
					Act_gasAnnualMembershipFeeGBP = response.jsonPath().getDouble("gasAnnualMembershipFeeGBP");
				}

				switch(memberId){
				case 47494:
					i = 1;
					rq.setExpectedResponse(getProp("Expected_Response"), "RetrieveQuotes", i);
					break;
				case 47366:
					i = 2;
					rq.setExpectedResponse(getProp("Expected_Response"), "RetrieveQuotes", i);
					break;
				default: 
					break;
				}

				//compare response elements

				if (Act_productType.equalsIgnoreCase("Dual")) 
				{
					rq.compareResponse_Dual(Act_memberId, Act_addressLine, Act_postcode, Act_productType, Act_mpans, Act_mprns, Act_quoteReason, Act_quoteReference, Act_tariffName, Act_savingAmountGBP, Act_carbonSavingskg, Act_annualQuoteAmountGBP, Act_minAnnualQuoteAmountGBP, Act_comparisonSupplier, Act_elecAnnualUsagekWhs, Act_elecUnitRate, Act_elecAnnualAmounIncMFGBP, Act_elecAnnualAmountExcMFGBP, Act_elecMonthlyMembershipFeeGBP, Act_elecAnnualMembershipFeeGBP, Act_gasAnnualUsagekWhs, Act_gasUnitRate, Act_gasAnnualAmountIncMFGBP, Act_gasAnnualAmountExcMFGBP, Act_gasMonthlyMembershipFeeGBP, Act_gasAnnualMembershipFeeGBP, Act_expiryDateTime);

				} else {
					rq.compareResponse_Elec(Act_memberId, Act_addressLine, Act_postcode, Act_productType, Act_mpans, Act_mprns, Act_quoteReason, Act_quoteReference, Act_tariffName, Act_savingAmountGBP, Act_carbonSavingskg, Act_annualQuoteAmountGBP, Act_minAnnualQuoteAmountGBP, Act_comparisonSupplier, Act_elecAnnualUsagekWhs, Act_elecUnitRate, Act_elecAnnualAmounIncMFGBP, Act_elecAnnualAmountExcMFGBP, Act_elecMonthlyMembershipFeeGBP, Act_elecAnnualMembershipFeeGBP, Act_expiryDateTime);
				}

			}
		}
		else if (API_name.equals("GET_Psr")) 
		{

			String homeAssistancePSRs,personalAssistanceNeedsPSRs,personalAssistanceCommunicationPSRs;
			String Act_otherConsideration, Act_authorisedContactName, Act_authorisedContactEmail, Act_password;
			boolean Act_sendForMeterRead,Act_sendEmailToAuthorisedContact;
			String[] Act_homeAssistancePSRs;
			String[] Act_personalAssistanceNeedsPSRs;
			String[] Act_personalAssistanceCommunicationPSRs;
			GET_Psr gp = new GET_Psr();
			if (respStatusCode == 200) 
			{
				Act_memberId = response.jsonPath().getInt("memberId");
				Act_otherConsideration = response.jsonPath().getString("otherConsideration");
				Act_authorisedContactName = response.jsonPath().getString("authorizationInformation.authorisedContactName");
				Act_authorisedContactEmail = response.jsonPath().getString("authorizationInformationauthorisedContactEmail");
				Act_sendForMeterRead = response.jsonPath().getBoolean("sendForMeterRead");
				Act_sendEmailToAuthorisedContact = response.jsonPath().getBoolean("authorizationInformation.sendEmailToAuthorisedContact");
				Act_password = response.jsonPath().getString("password");

				homeAssistancePSRs = response.jsonPath().getString("homeAssistancePSRs.description");			
				String a = homeAssistancePSRs.replace("[", "");
				String b = a.replace("]", "");
				//System.out.println("description: "+b);
				Act_homeAssistancePSRs = b.split(",");

				personalAssistanceNeedsPSRs = response.jsonPath().getString("personalAssistanceNeedsPSRs.description");
				String c = personalAssistanceNeedsPSRs.replace("[", "");
				String d = c.replace("]", "");
				Act_personalAssistanceNeedsPSRs = d.split(",");

				personalAssistanceCommunicationPSRs = response.jsonPath().getString("personalAssistanceCommunicationPSRs.description");
				String e = personalAssistanceCommunicationPSRs.replace("[", "");
				String f = e.replace("]", "");
				Act_personalAssistanceCommunicationPSRs = f.split(",");

				switch (memberId) 
				{
				case 22287:
					i = 1;
					gp.setExpectedResponse(getProp("Expected_Response"), "GET_PSR", i);
					break;

				default:
					break;
				}
				gp.compareResponse(Act_memberId, Act_homeAssistancePSRs, Act_personalAssistanceNeedsPSRs, Act_personalAssistanceCommunicationPSRs, Act_otherConsideration, Act_authorisedContactName, Act_authorisedContactEmail, Act_sendEmailToAuthorisedContact, Act_password, Act_sendForMeterRead);

				//psrRegistered = response.jsonPath().getBoolean("homeAssistancePSRs.psrRegistered");

				//System.out.println("psrRegistered "+psrRegistered);


				/*JSONArray Act_homeAssistancePSRs = new JSONArray();


				Act_homeAssistancePSRs = response.jsonPath().getJsonObject("homeAssistancePSRs");
				for (int i = 0; i < Act_homeAssistancePSRs.size(); i++) 
				{
					JSONObject ob = new JSONObject();
					ob = (JSONObject) Act_homeAssistancePSRs.get(i);

					description = ob.get("description").toString();
					System.out.println(description);


				}*/

				// create a json object and store all the respective json array elements
				// then check for description and psrRegistered

				// or fetch the value directly using json path without using JSONArray
				// check how to differentiate between two array elements which has same name
			}
		}
	}




	/*
	 * ***************** MI POST *********************** 
	 */


	@SuppressWarnings("unchecked")
	@Given("^firstName, lastName and email as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void firstname_lastName_and_email_as(String firstName, String lastName, String email) throws Throwable 
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		//JSONObject requestParams = new JSONObject();
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		//RestAssured.log().body();
	}

	@SuppressWarnings("unchecked")
	@Given("^all the request parameters are passed as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void all_the_request_parameters_are_passed_as(String title, String firstName, String lastName, String email, String mobile, String dob, String refCode, String refSource, String refEmail) throws Throwable 
	{
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.mobile = mobile;
		this.dob = dob;
		this.refCode = refCode;
		this.refSource = refSource;
		this.refEmail = refEmail;

		//JSONObject requestParams = new JSONObject();
		requestParams.put("title", title);
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		requestParams.put("mobile", mobile);
		requestParams.put("dateOfBirth", dob);
		requestParams.put("referralCode", refCode);
		requestParams.put("referralSource", refSource);
		requestParams.put("referralEmail", refEmail);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());


	}

	@SuppressWarnings("unchecked")
	@Given("^title, firstName, lastName,email, mobile and dob as \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void title_firstName_lastName_email_mobile_and_dob_as(String title, String firstName, String lastName, String email, String mobile, String dob) throws Throwable 
	{
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.mobile = mobile;
		this.dob = dob;
		//JSONObject requestParams = new JSONObject();
		requestParams.put("title", title);
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		requestParams.put("mobile", mobile);
		requestParams.put("dateOfBirth", dob);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		System.out.println(req);
	}

	@SuppressWarnings("unchecked")
	@Given("^firstName, lastName, email, referralCode, referralSource and referralEmail as  \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void firstname_lastName_email_referralCode_referralSource_and_referralEmail_as(String firstName, String lastName, String email, String refCode, String refSource, String refEmail) throws Throwable 
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.refCode = refCode;
		this.refSource = refSource;
		this.refEmail = refEmail;
		//JSONObject requestParams = new JSONObject();
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		requestParams.put("referralCode", refCode);
		requestParams.put("referralSource", refSource);
		requestParams.put("referralEmail", refEmail);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		System.out.println(req);
	}

	@When("^request is POSTed to url \"([^\"]*)\"$")
	public void request_is_POSTed_to_url(String url) throws Throwable {
		String Baseurl = url;
		//pass header parameters
		if ("App".equals(Client_Id)) 
		{
			req.header("Content-Type","application/json");
			req.header("Device-Advertising-ID",Device_Advertising_ID);
			req.header("Device-Notification-ID",Device_Notification_ID);
			req.header("Device-Type",Device_Type);
			req.header("Client-Id",Client_Id);
			req.header("Pure-Tracking-Id",Pure_Tracking_Id);
		}
		else 
		{
			req.header("Content-Type","application/json");
			req.header("Client-Id",Client_Id);
			req.header("Pure-Tracking-Id",Pure_Tracking_Id);
		}
		System.out.println("baseUrl: "+Baseurl);

		response = req.relaxedHTTPSValidation().post(Baseurl);
		//response = req.post(Baseurl);
		System.out.println("response: " + response.prettyPrint());


	}


	/*
	 * ********************* MI Login *************************
	 */


	@SuppressWarnings("unchecked")
	@Given("^verify url is passed as \"([^\"]*)\"$")
	public void verify_url_is_passed_as(String verifyUrl) throws Throwable 
	{
		//JSONObject requestParams = new JSONObject();
		requestParams.put("verifyUrl", verifyUrl);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	@SuppressWarnings("unchecked")
	@Given("^verify url and reason is passed as \"([^\"]*)\",\"([^\"]*)\"$")
	public void verify_url_and_reason_is_passed_as(String verifyUrl, String reason) throws Throwable 
	{
		//JSONObject requestParams = new JSONObject();
		requestParams.put("verifyUrl", verifyUrl);
		requestParams.put("reason", reason);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	/*
	 * *********************** MI Verify **************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^verification token is passed$")
	public void verification_token_is_passed() throws Throwable 
	{
		GenericMethods gm = new GenericMethods();
		String token = gm.getVerificationCode(getProp("Old_Dev"));
		requestParams.put("token", token);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}


	@SuppressWarnings("unchecked")
	@Given("^verification token is passed as \"([^\"]*)\"$")
	public void verification_token_is_passed_as(String token) throws Throwable 
	{
		//JSONObject requestParams = new JSONObject();
		requestParams.put("token", token);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^verification token is passed \"([^\"]*)\"$")
	public void verification_token_is_passed(String url) throws Throwable 
	{
		GenericMethods gm = new GenericMethods();

		if(url.contains("Dev")) 
		{
			String token = gm.getVerificationCode(getProp("Old_Dev"));
			requestParams.put("token", token);
			RequestSpecification request = RestAssured.given();
			req = request.body(requestParams.toJSONString());
		}
		else if(url.contains("TEST_ESB1")) 
		{	
			String token = gm.getVerificationCode(getProp("Old_Test_ESB1"));
			requestParams.put("token", token);
			RequestSpecification request = RestAssured.given();
			req = request.body(requestParams.toJSONString());
		} 
		else if(url.contains("TEST_ESB2"))
		{
			String token = gm.getVerificationCode(getProp("Old_Test_ESB2"));
			requestParams.put("token", token);
			RequestSpecification request = RestAssured.given();
			req = request.body(requestParams.toJSONString());
		}
		else if(url.contains("Bastion")) 
		{
			String token = gm.getVerificationCode(getProp("Bastion"));
			requestParams.put("token", token);
			RequestSpecification request = RestAssured.given();
			req = request.body(requestParams.toJSONString());
		}
	}



	//********************** MI PUT ******************************

	@When("^member tries to update$")
	public void member_tries_to_update() throws Throwable 
	{
		String Baseurl = FinalUrl;
		//pass header parameters
		if ("App".equals(Client_Id)) 
		{
			req.header("Content-Type","application/json");
			req.header("Device-Advertising-ID",Device_Advertising_ID);
			req.header("Device-Notification-ID",Device_Notification_ID);
			req.header("Device-Type",Device_Type);
			req.header("Client-Id",Client_Id);
			req.header("Pure-Tracking-Id",Pure_Tracking_Id);
		}
		else 
		{
			req.header("Content-Type","application/json");
			req.header("Client-Id",Client_Id);
			req.header("Pure-Tracking-Id",Pure_Tracking_Id);
		}
		response = req.relaxedHTTPSValidation().put(Baseurl);
		//Response response = req.put(Baseurl);
		System.out.println("response: " + response.prettyPrint());


	}

	@SuppressWarnings("unchecked")
	@Given("^all the request parameters are passed except email \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void all_the_request_parameters_are_passed_except_email(String title, String firstName, String lastName, String dateOfBirth, String mobileNo, String communityId, String referralCode, String referralSource, String referralEmail) throws Throwable 
	{
		this.title = title;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobile = mobileNo;
		this.dob = dateOfBirth;
		this.refCode = referralCode;
		this.refSource = referralSource;
		this.refEmail = referralEmail;
		//JSONObject requestParams = new JSONObject();
		requestParams.put("title", title);
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("dateOfBirth", dateOfBirth);
		requestParams.put("mobileNo", title);
		requestParams.put("communityId", communityId);
		requestParams.put("referralCode", referralCode);
		requestParams.put("referralSource", referralSource);
		requestParams.put("referralEmail", referralEmail);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^referralCode, referralSource and referral email are passed as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void referralcode_referralSource_and_referral_email_are_passed_as(String referralCode, String referralSource, String referralEmail) throws Throwable 
	{
		this.refCode = referralCode;
		this.refSource = referralSource;
		this.refEmail = referralEmail;
		//JSONObject  requestParams = new JSONObject();
		requestParams.put("referralCode", referralCode);
		requestParams.put("referralSource", referralSource);
		requestParams.put("referralEmail", referralEmail);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	//************************************ Address ********************************

	@Given("^Postcode as \"([^\"]*)\" and url as \"([^\"]*)\"$")
	public void postcode_as_and_url_as(String postCode, String url) throws Throwable 
	{
		//System.setOut(new PrintStream(new FileOutputStream("D:/Apoorva/Pure Energy/RRL/eclipse responses/Address/Address_"+GenericMethods.date()+"_"+postCode+".txt")));
		req = given().param("postcode:" + postCode);
		FinalUrl = url.concat("/"+postCode);
		System.out.println(FinalUrl);
		this.postCode = postCode;


	}

	@When("^address details are retrieved$")
	public void address_details_are_retrieved() throws Throwable {
		//pass header parameters
		if ("App".equals(Client_Id)) 
		{
			req.header("Content-Type","application/json");
			req.header("Device-Advertising-ID",Device_Advertising_ID);
			req.header("Device-Notification-ID",Device_Notification_ID);
			req.header("Device-Type",Device_Type);
			req.header("Client-Id",Client_Id);
			req.header("Pure-Tracking-Id",Pure_Tracking_Id);
		}
		else 
		{
			req.header("Content-Type","application/json");
			req.header("Client-Id",Client_Id);
			req.header("Pure-Tracking-Id",Pure_Tracking_Id);
		}
		response = req.relaxedHTTPSValidation().get(FinalUrl);

		//print the response
		response.prettyPrint();
		System.out.println();

	}


	//********************************** Member Identity Quotes ***********************

	@SuppressWarnings("unchecked")
	@Given("^addressLine, postcode, productType, mpans, mprns, consumption, quoteReason, verifyDeeplinkURL as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\"$")
	public void addressline_postcode_productType_mpans_mprns_consumption_quoteReason_verifyDeeplinkURL_as(String addressLine, String postCode, String productType, String mpans, String mprns, String consumption, String quoteReason, String verifyDeeplinkURL) throws Throwable 
	{
		JSONObject usage = new JSONObject();
		JSONArray mpan = new JSONArray();
		mpan.add(mpans);
		JSONArray mprn = new JSONArray();
		mprn.add(mprns);
		usage.put("consumption", consumption);
		requestParams.put("addressLine", addressLine);
		requestParams.put("postcode", postCode);
		requestParams.put("productType", productType);
		requestParams.put("mpans", mpan);
		requestParams.put("mprns", mprn);
		requestParams.put("usage", usage);
		requestParams.put("quoteReason", quoteReason);
		requestParams.put("verifyDeeplinkURL", verifyDeeplinkURL);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());	

	}

	@SuppressWarnings("unchecked")
	@Given("^addressLine, postcode, productType, productType, referenceProductType, selectedMeterType, referenceMeterType, mpans, mprns, currentkWhUsageElec, currentkWhUsageGas, quoteReason, verifyDeeplinkURL as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\"$")
	public void addressline_postcode_productType_productType_referenceProductType_selectedMeterType_referenceMeterType_mpans_mprns_currentkWhUsageElec_currentkWhUsageGas_quoteReason_verifyDeeplinkURL_as(String addressLine, String postcode, String productType, String referenceProductType, String selectedMeterType, String referenceMeterType, String mpans, String mprns, String currentkWhUsageElec, String currentkWhUsageGas, String quoteReason, String verifyDeeplinkURL) throws Throwable 
	{
		JSONObject usage = new JSONObject();
		JSONArray mpan = new JSONArray();
		mpan.add(mpans);
		JSONArray mprn = new JSONArray();
		mprn.add(mprns);
		usage.put("currentkWhUsageElec", currentkWhUsageElec);
		usage.put("currentkWhUsageGas", currentkWhUsageGas);
		requestParams.put("addressLine", addressLine);
		requestParams.put("postcode", postcode);
		requestParams.put("productType", productType);
		requestParams.put("referenceProductType", referenceProductType);
		requestParams.put("selectedMeterType", selectedMeterType);
		requestParams.put("referenceMeterType", referenceMeterType);
		requestParams.put("mpans", mpan);
		requestParams.put("mprns", mprn);
		requestParams.put("usage", usage);
		requestParams.put("quoteReason", quoteReason);
		requestParams.put("verifyDeeplinkURL", verifyDeeplinkURL);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^addressLine, postcode, productType, mpans, mprns, currentkWhUsageElec, quoteReason, verifyDeeplinkURL as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void addressline_postcode_productType_mpans_mprns_currentkWhUsageElec_quoteReason_verifyDeeplinkURL_as(String addressLine, String postcode, String productType, String mpans, String mprns, String currentkWhUsageElec, String quoteReason, String verifyDeeplinkURL) throws Throwable 
	{
		JSONObject usage = new JSONObject();
		JSONArray mpan = new JSONArray();
		mpan.add(mpans);
		JSONArray mprn = new JSONArray();
		mprn.add(mpans);
		usage.put("currentkWhUsageElec", currentkWhUsageElec);
		requestParams.put("addressLine", addressLine);
		requestParams.put("postcode", postcode);
		requestParams.put("productType", productType);
		requestParams.put("mpans", mpan);
		requestParams.put("mprns", mprn);
		requestParams.put("usage", usage);
		requestParams.put("quoteReason", quoteReason);
		requestParams.put("verifyDeeplinkURL", verifyDeeplinkURL);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	//************Provision Energy Member *******************

	@SuppressWarnings("unchecked")
	@Given("^memberId, ownership, bankAccountName, accountNumber, sortCode, psrRequired as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_ownership_bankAccountName_accountNumber_sortCode_psrRequired_as(String memberId, String ownership, String bankAccountName, String accountNumber, String sortCode, String psrRequired) throws Throwable 
	{
		JSONObject ddMandateDetails = new JSONObject();
		ddMandateDetails.put("bankAccountName", bankAccountName);
		ddMandateDetails.put("accountNumber", accountNumber);
		ddMandateDetails.put("sortCode", sortCode);

		boolean psr_R = Boolean.parseBoolean(psrRequired);

		requestParams.put("memberId", memberId);
		requestParams.put("ownership", ownership);
		requestParams.put("ddMandateDetails", ddMandateDetails);
		requestParams.put("psrRequired", psr_R);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	/*
	 * *************************************** Customer Enquiry *****************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^enquiry reason is given as \"([^\"]*)\"$")
	public void enquiry_reason_is_given_as(String reason) throws Throwable 
	{
		this.reason = reason;
		requestParams.put("enquiryReason", reason);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 * ******************************** Bank Account Validation *******************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^accountNumber and sortCode as \"([^\"]*)\",\"([^\"]*)\"$")
	public void accountnumber_and_sortCode_as(String accountNumber, String sortCode) throws Throwable 
	{
		requestParams.put("accountNumber", accountNumber);
		requestParams.put("sortCode", sortCode);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 * ****************************** Complaints ********************************************
	 */
	@SuppressWarnings("unchecked")
	@Given("^memberId, preferredContactTime, natureOfEnquiry, reason and additionalInformation as (\\d+),\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\"$")
	public void memberid_preferredContactTime_natureOfEnquiry_reason_and_additionalInformation_as(int memberId, String preferredContactTime, String natureOfEnquiry, String reason, String additionalInformation) throws Throwable 
	{
		requestParams.put("memberId", memberId);
		requestParams.put("preferredContactTime", preferredContactTime);
		requestParams.put("natureOfEnquiry", natureOfEnquiry);
		requestParams.put("reason", reason);
		requestParams.put("additionalInformation", additionalInformation);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^name, email, phone, preferredContactTime, natureOfEnquiry, reason and additionalInformation as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\"$")
	public void name_email_phone_preferredContactTime_natureOfEnquiry_reason_and_additionalInformation_as(String name, String email, String phone, String preferredContactTime, String natureOfEnquiry, String reason, String additionalInformation) throws Throwable 
	{
		requestParams.put("name", name);
		requestParams.put("email", email);
		requestParams.put("phone", phone);
		requestParams.put("preferredContactTime", preferredContactTime);
		requestParams.put("natureOfEnquiry", natureOfEnquiry);
		requestParams.put("reason", reason);
		requestParams.put("additionalInformation", additionalInformation);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	/*
	 * ************************************* Quotes ***********************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^postCode, productType and consumption as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void postcode_productType_and_consumption_as(String postcode, String productType, String consumption) throws Throwable 
	{
		JSONObject usage = new JSONObject();
		usage.put("consumption", consumption);
		requestParams.put("postcode", postcode);
		requestParams.put("productType", productType);
		requestParams.put("usage", usage);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	@SuppressWarnings("unchecked")
	@Given("^postCode, productType, currentkWhUsageElec and currentkWhUsageGas as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void postcode_productType_currentkWhUsageElec_and_currentkWhUsageGas_as(String postcode, String productType, String currentkWhUsageElec, String currentkWhUsageGas) throws Throwable 
	{
		JSONObject usage = new JSONObject();
		usage.put("currentkWhUsageElec", currentkWhUsageElec);
		usage.put("currentkWhUsageGas", currentkWhUsageGas);
		requestParams.put("postcode", postcode);
		requestParams.put("productType", productType);
		requestParams.put("usage", usage);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^postCode, productType and currentkWhUsageElec as \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\"$")
	public void postcode_productType_and_currentkWhUsageElec_as(String postcode, String productType, String currentkWhUsageElec) throws Throwable 
	{
		JSONObject usage = new JSONObject();
		usage.put("currentkWhUsageElec", currentkWhUsageElec);
		requestParams.put("postcode", postcode);
		requestParams.put("productType", productType);
		requestParams.put("usage", usage);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 * *************************** PUT Phone Number *******************************
	 */


	@SuppressWarnings("unchecked")
	@Given("^phoneNumber to be updated is \"([^\"]*)\"$")
	public void phonenumber_to_be_updated_is(String phoneNumber) throws Throwable 
	{
		requestParams.put("phoneNumber", phoneNumber);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());


	}

	/*
	 * *************************** POST PSR *********************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^PSRs, otherMedicalDependency, otherConsideration, authorisedContactName, authorisedContactEmail, sendEmailToAuthorisedContact,password and sendForMeterRead as  \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void psrs_otherMedicalDependency_otherConsideration_authorisedContactName_authorisedContactEmail_sendEmailToAuthorisedContact_password_and_sendForMeterRead_as(String PSR1, String PSR2, String PSR3, String PSR4, String PSR5, String PSR6, String PSR7, String PSR8, String PSR9, String PSR10, String PSR11, String PSR12, String PSR13, String PSR14, String PSR15, String PSR16, String PSR17, String PSR18, String PSR19, String PSR20, String PSR21, String PSR22, String PSR23, String PSR24, String PSR25, String PSR26,String otherMedicalDependency, String otherConsideration, String authorisedContactName, String authorisedContactEmail, String sendEmailToAuthorisedContact, String password, String sendForMeterRead) throws Throwable 
	{
		boolean sendEmailToAuthorisedContact1 = Boolean.parseBoolean(sendEmailToAuthorisedContact);
		boolean sendForMeterRead1 = Boolean.parseBoolean(sendForMeterRead);

		JSONObject authorizationInformation = new JSONObject();
		authorizationInformation.put("authorisedContactName", authorisedContactName);
		authorizationInformation.put("authorisedContactEmail", authorisedContactEmail);
		authorizationInformation.put("sendEmailToAuthorisedContact",sendEmailToAuthorisedContact1);

		JSONArray psr = new JSONArray();
		psr.add(PSR1);
		psr.add(PSR2);
		psr.add(PSR3);
		psr.add(PSR4);
		psr.add(PSR5);
		psr.add(PSR6);
		psr.add(PSR7);
		psr.add(PSR8);
		psr.add(PSR9);
		psr.add(PSR10);
		psr.add(PSR11);
		psr.add(PSR12);
		psr.add(PSR13);
		psr.add(PSR14);
		psr.add(PSR15);
		psr.add(PSR16);
		psr.add(PSR17);
		psr.add(PSR18);
		psr.add(PSR19);
		psr.add(PSR20);
		psr.add(PSR21);
		psr.add(PSR22);
		psr.add(PSR23);
		psr.add(PSR24);
		psr.add(PSR25);
		psr.add(PSR26);

		requestParams.put("PSRs", psr);
		requestParams.put("otherMedicalDependency", otherMedicalDependency);
		requestParams.put("otherConsideration", otherConsideration);
		requestParams.put("authorizationInformation", authorizationInformation);
		requestParams.put("password", password);
		requestParams.put("sendForMeterRead", sendForMeterRead1);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^PSRs, otherMedicalDependency, otherConsideration, authorisedContactName, authorisedContactEmail, sendEmailToAuthorisedContact,password and sendForMeterRead as \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void psrs_otherMedicalDependency_otherConsideration_authorisedContactName_authorisedContactEmail_sendEmailToAuthorisedContact_password_and_sendForMeterRead_as(String PSR1, String PSR2, String otherMedicalDependency, String otherConsideration, String authorisedContactName, String authorisedContactEmail, String sendEmailToAuthorisedContact, String password, String sendForMeterRead) throws Throwable 
	{
		boolean sendEmailToAuthorisedContact1 = Boolean.parseBoolean(sendEmailToAuthorisedContact);
		boolean sendForMeterRead1 = Boolean.parseBoolean(sendForMeterRead);

		JSONObject authorizationInformation = new JSONObject();
		authorizationInformation.put("authorisedContactName", authorisedContactName);
		authorizationInformation.put("authorisedContactEmail", authorisedContactEmail);
		authorizationInformation.put("sendEmailToAuthorisedContact",sendEmailToAuthorisedContact1);

		JSONArray psr = new JSONArray();
		psr.add(PSR1);
		psr.add(PSR2);

		requestParams.put("PSRs", psr);
		requestParams.put("otherMedicalDependency", otherMedicalDependency);
		requestParams.put("otherConsideration", otherConsideration);
		requestParams.put("authorizationInformation", authorizationInformation);
		requestParams.put("password", password);
		requestParams.put("sendForMeterRead", sendForMeterRead1);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 * ******************** PUT direct debit date *****************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^direct debit date as \"([^\"]*)\"$")
	public void direct_debit_date_as(String date) throws Throwable 
	{
		requestParams.put("directDebitDate", date);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}


	/*
	 * ********************** MI POST Type ***********************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^memberId and type are passed as \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_and_type_are_passed_as(String memberId, String type) throws Throwable 
	{
		requestParams.put("memberId", memberId);
		requestParams.put("type", type);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 * ******************** Cancel Switch **********************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^memberId, preferredContactTime, natureOfEnquiry and reason as (\\d+), \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_preferredContactTime_natureOfEnquiry_and_reason_as(int memberId, String preferredContactTime, String natureOfEnquiry, String reason) throws Throwable 
	{
		requestParams.put("memberId", memberId);
		requestParams.put("preferredContactTime", preferredContactTime);
		requestParams.put("natureOfEnquiry", natureOfEnquiry);
		requestParams.put("reason", reason);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 * *********************** Validate Meter Reading ****************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointIda, readingValuea, meterpointIdb, readingValueb as (\\d+), \"([^\"]*)\", (\\d+), \"([^\"]*)\", (\\d+)$")
	public void memberid_meterpointIda_readingValuea_meterpointIdb_readingValueb_as(int memberId, String meterpointIda, int readingValuea, String meterpointIdb, int readingValueb) throws Throwable 
	{
		JSONObject registers1 = new JSONObject();
		registers1.put("readingValue", readingValuea);
		JSONObject registers2 = new JSONObject();
		registers2.put("readingValue", readingValueb);

		JSONArray reg1 = new JSONArray();
		reg1.add(registers1);
		JSONArray reg2 = new JSONArray();
		reg2.add(registers2);

		JSONObject valMtr1 = new JSONObject();
		valMtr1.put("meterpointId", meterpointIda);
		valMtr1.put("registers", reg1);
		JSONObject valMtr2 = new JSONObject();
		valMtr2.put("meterpointId", meterpointIdb);
		valMtr2.put("registers", reg2);

		JSONArray validateMeterReads = new JSONArray();
		validateMeterReads.add(valMtr1);
		validateMeterReads.add(valMtr2);

		requestParams.put("memberId", memberId);
		requestParams.put("validateMeterReads", validateMeterReads);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());


	}

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointIda, meterIdentifiera, readingValuea, registerLabela, registerIdentifiera, meterpointIdb, meterIdentifierb, readingValueb, registerLabelb registerIdentifierb (\\d+), \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_meterpointIda_meterIdentifiera_readingValuea_registerLabela_registerIdentifiera_meterpointIdb_meterIdentifierb_readingValueb_registerLabelb_registerIdentifierb(int memberId, String meterpointIda, String meterIdentifiera, int readingValuea, String registerLabela, String registerIdentifiera, String meterpointIdb, String meterIdentifierb, int readingValueb, String registerLabelb, String registerIdentifierb) throws Throwable 
	{
		String meterIdena;
		String regLabela;
		String regIdena;
		String meterIdenb;
		String regLabelb;
		String regIdenb;

		if (meterIdentifiera.equals("null")) {
			meterIdena = null;
		}else{
			meterIdena = meterIdentifiera;
		}

		if (registerLabela.equals("null")) {
			regLabela = null;
		}else{
			regLabela = registerLabela;
		}

		if (registerIdentifiera.equals("null")) {
			regIdena = null;
		}else{
			regIdena = registerIdentifiera;
		}

		if (meterIdentifierb.equals("null")) {
			meterIdenb = null;
		}else{
			meterIdenb = meterIdentifierb;
		}

		if (registerLabelb.equals("null")) {
			regLabelb = null;
		}else{
			regLabelb = registerLabelb;
		}

		if (registerIdentifierb.equals("null")) {
			regIdenb = null;
		}else{
			regIdenb = registerIdentifierb;
		}

		JSONObject reg1 = new JSONObject();
		reg1.put("readingValue", readingValuea);
		reg1.put("registerLabel", regLabela);
		reg1.put("registerIdentifier", regIdena);

		JSONObject reg2 = new JSONObject();
		reg2.put("readingValue", readingValueb);
		reg2.put("registerLabel", regLabelb);
		reg2.put("registerIdentifier", regIdenb);

		JSONArray regArr1 = new JSONArray();
		regArr1.add(reg1);
		JSONArray regArr2 = new JSONArray();
		regArr2.add(reg2);

		JSONObject valMet1 = new JSONObject();
		valMet1.put("meterpointId", meterpointIda);
		valMet1.put("meterIdentifier", meterIdena);
		valMet1.put("registers", regArr1);

		JSONObject valMet2 = new JSONObject();
		valMet2.put("meterpointId", meterpointIdb);
		valMet2.put("meterIdentifier", meterIdenb);
		valMet2.put("registers", regArr2);

		JSONArray validateMeterReads = new JSONArray();
		validateMeterReads.add(valMet1);
		validateMeterReads.add(valMet2);

		requestParams.put("memberId", memberId);
		requestParams.put("validateMeterReads", validateMeterReads);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointIda, meterIdentifiera, readingValue_d, registerLabel_d, registerIdentifier_d, readingValue_n, registerLabel_n, registerIdentifier_n, meterpointIdb, meterIdentifierb, readingValueb, registerLabelb, registerIdentifierb as (\\d+), \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\",\"([^\"]*)\"$")
	public void memberid_meterpointIda_meterIdentifiera_readingValue_d_registerLabel_d_registerIdentifier_d_readingValue_n_registerLabel_n_registerIdentifier_n_meterpointIdb_meterIdentifierb_readingValueb_registerLabelb_registerIdentifierb_as(int memberId, String meterpointIda, String meterIdentifiera, int readingValue_d, String registerLabel_d, String registerIdentifier_d, int readingValue_n, String registerLabel_n, String registerIdentifier_n, String meterpointIdb, String meterIdentifierb, int readingValueb, String registerLabelb, String registerIdentifierb) throws Throwable 
	{
		String meterIdena;
		String regLabel_d;
		String regIden_d;
		String regLabel_n;
		String regIden_n;
		String meterIdenb;
		String regLabelb;
		String regIdenb;

		if (meterIdentifiera.equals("null")) {
			meterIdena = null;
		} else {
			meterIdena = meterIdentifiera;
		}

		if (registerLabel_d.equals("null")) {
			regLabel_d = null;
		} else {
			regLabel_d = registerLabel_d;
		}

		if (registerIdentifier_d.equals("null")) {
			regIden_d = null;
		} else {
			regIden_d = registerIdentifier_d;
		}

		if (registerLabel_n.equals("null")) {
			regLabel_n = null;
		} else {
			regLabel_n = registerLabel_n;
		}

		if (registerIdentifier_n.equals("null")) {
			regIden_n = null;
		} else {
			regIden_n = registerIdentifier_n;
		}

		if (meterIdentifierb.equals("null")) {
			meterIdenb = null;
		} else {
			meterIdenb = meterIdentifierb;
		}

		if (registerLabelb.equals("null")) {
			regLabelb = null;
		} else {
			regLabelb = registerLabelb;
		}

		if (registerIdentifierb.equals("null")) {
			regIdenb = null;
		} else {
			regIdenb = registerIdentifierb;
		}

		JSONObject reg_d = new JSONObject();
		reg_d.put("readingValue", readingValue_d);
		reg_d.put("registerLabel", regLabel_d);
		reg_d.put("registerIdentifier", regIden_d);

		JSONObject reg_n = new JSONObject();
		reg_n.put("readingValue", readingValue_n);
		reg_n.put("registerLabel", regLabel_n);
		reg_n.put("registerIdentifier", regIden_n);

		JSONObject regb = new JSONObject();
		regb.put("readingValue", readingValueb);
		regb.put("registerLabel", regLabelb);
		regb.put("registerIdentifier", regIdenb);

		JSONArray regArrayA = new JSONArray();
		regArrayA.add(reg_d);
		regArrayA.add(reg_n);

		JSONArray regArrayB = new JSONArray();
		regArrayB.add(regb);

		JSONObject valMtrA = new JSONObject();
		valMtrA.put("meterpointId", meterpointIda);
		valMtrA.put("meterIdentifier", meterIdena);
		valMtrA.put("registers", regArrayA);

		JSONObject valMtrB = new JSONObject();
		valMtrB.put("meterpointId", meterpointIdb);
		valMtrB.put("meterIdentifier", meterIdenb);
		valMtrB.put("registers", regArrayB);

		JSONArray validateMeterReads = new JSONArray();
		validateMeterReads.add(valMtrA);
		validateMeterReads.add(valMtrB);

		requestParams.put("memberId", memberId);
		requestParams.put("validateMeterReads", validateMeterReads);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointId, meterIdentifier, readingValue, registerLabel, registerIdentifier as (\\d+), \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_meterpointId_meterIdentifier_readingValue_registerLabel_registerIdentifier_as(int memberId, String meterpointId, String meterIdentifier, int readingValue, String registerLabel, String registerIdentifier) throws Throwable 
	{
		String meterIden;
		String regLabel;
		String regIden;

		if (meterIdentifier.equals("null")) {
			meterIden = null;
		} else {
			meterIden = meterIdentifier;
		}
		if (registerLabel.equals("null")) {
			regLabel = null;
		} else {
			regLabel = registerLabel;
		}
		if (registerIdentifier.equals("null")) {
			regIden = null;
		} else {
			regIden = registerIdentifier;
		}

		JSONObject reg = new JSONObject();
		reg.put("readingValue", readingValue);
		reg.put("registerLabel", regLabel);
		reg.put("registerIdentifier", regIden);

		JSONArray regArr = new JSONArray();
		regArr.add(reg);

		JSONObject valMtrRead = new JSONObject();
		valMtrRead.put("meterpointId", meterpointId);
		valMtrRead.put("meterIdentifier", meterIden);
		valMtrRead.put("registers", regArr);

		JSONArray validateMeterReads = new JSONArray();
		validateMeterReads.add(valMtrRead);

		requestParams.put("memberId", memberId);
		requestParams.put("validateMeterReads", validateMeterReads);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointId, meterIdentifier, readingValue_d, registerLabel_d, registerIdentifier_d, readingValue_n, registerLabel_n, registerIdentifier_n as (\\d+), \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_meterpointId_meterIdentifier_readingValue_d_registerLabel_d_registerIdentifier_d_readingValue_n_registerLabel_n_registerIdentifier_n_as(int memberId, String meterpointId, String meterIdentifier, int readingValue_d, String registerLabel_d, String registerIdentifier_d, int readingValue_n, String registerLabel_n, String registerIdentifier_n) throws Throwable 
	{
		String meterIden;
		String regLabel_d;
		String regIden_d;
		String regLabel_n;
		String regIden_n;

		if (meterIdentifier.equals("null")) {
			meterIden = null;
		} else {
			meterIden = meterIdentifier;
		}
		if (registerLabel_d.equals("null")) {
			regLabel_d = null;
		} else {
			regLabel_d = registerLabel_d;
		}
		if (registerLabel_n.equals("null")) {
			regLabel_n = null;
		} else {
			regLabel_n = registerLabel_n;
		}
		if (registerIdentifier_d.equals("null")) {
			regIden_d = null;
		} else {
			regIden_d = registerIdentifier_d;
		}
		if (registerIdentifier_n.equals("null")) {
			regIden_n = null;
		} else {
			regIden_n = registerIdentifier_n;
		}

		JSONObject reg1 = new JSONObject();
		reg1.put("readingValue", readingValue_d);
		reg1.put("registerLabel", regLabel_d);
		reg1.put("registerIdentifier", regIden_d);

		JSONObject reg2 = new JSONObject();
		reg2.put("readingValue", readingValue_n);
		reg2.put("registerLabel", regLabel_n);
		reg2.put("registerIdentifier", regIden_n);

		JSONArray registers = new JSONArray();
		registers.add(reg1);
		registers.add(reg2);

		JSONObject valMtrArray = new JSONObject();
		valMtrArray.put("meterpointId", meterpointId);
		valMtrArray.put("meterIdentifier", meterIden);
		valMtrArray.put("registers", registers);

		JSONArray validateMeterReads = new JSONArray();
		validateMeterReads.add(valMtrArray);

		requestParams.put("memberId", memberId);
		requestParams.put("validateMeterReads", validateMeterReads);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	/*
	 * ******************* POST Meter Reading ************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointId_e, readingValue_e, meterpointId_g, readingValue_g as (\\d+), \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_meterpointId_e_readingValue_e_meterpointId_g_readingValue_g_as(int memberId, String meterpointId_e, String readingValue_e, String meterpointId_g, String readingValue_g) throws Throwable 
	{
		JSONObject reg1 = new JSONObject();
		reg1.put("readingValue", readingValue_e);
		JSONObject reg2 = new JSONObject();
		reg2.put("readingValue", readingValue_g);

		JSONArray regArray1 = new JSONArray();
		regArray1.add(reg1);
		JSONArray regArray2 = new JSONArray();
		regArray2.add(reg2);

		JSONObject cMeterReads1 = new JSONObject();
		cMeterReads1.put("meterpointId", meterpointId_e);
		cMeterReads1.put("registers", regArray1);

		JSONObject cMeterReads2 = new JSONObject();
		cMeterReads2.put("meterpointId", meterpointId_e);
		cMeterReads2.put("registers", regArray2);

		JSONArray collectedMeterReads = new JSONArray();
		collectedMeterReads.add(cMeterReads1);
		collectedMeterReads.add(cMeterReads2);

		requestParams.put("memberId", memberId);
		requestParams.put("collectedMeterReads", collectedMeterReads);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}


	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointId_e, meterIdentifier_e, photoPath_e, photoSkipped_e, readingValue_e, registerLabel_e, registerIdentifier_e, meterpointId_g,meterIdentifier_g, photoPath_g, readingValue_g, registerLabel_g, registerIdentifier_g as (\\d+), \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_meterpointId_e_meterIdentifier_e_photoPath_e_photoSkipped_e_readingValue_e_registerLabel_e_registerIdentifier_e_meterpointId_g_meterIdentifier_g_photoPath_g_readingValue_g_registerLabel_g_registerIdentifier_g_as(int memberId, String meterpointId_e, String meterIdentifier_e, String photoPath_e, String photoSkipped_e, String readingValue_e, String registerLabel_e, String registerIdentifier_e, String meterpointId_g, String meterIdentifier_g, String photoPath_g, String readingValue_g, String registerLabel_g, String registerIdentifier_g) throws Throwable 
	{
		String photopath_e;
		boolean photoSkip_e;
		String regLabel_e;
		String regIden_e;
		String photopath_g;
		String regLabel_g;
		String regIden_g;
		String meterIden_e;
		String meterIden_g;


		if (photoPath_e.equals("null")) {
			photopath_e = null;
		} else {
			photopath_e = photoPath_e;
		}

		if (photoSkipped_e.equals("true")) {
			photoSkip_e = true;
		} else {
			photoSkip_e = false;
		}

		if (registerLabel_e.equals("null")) {
			regLabel_e = null;
		} else {
			regLabel_e = registerLabel_e;
		}

		if (registerIdentifier_e.equals("null")) {
			regIden_e = null;
		} else {
			regIden_e = registerIdentifier_e;
		}

		if (photoPath_g.equals("null")) {
			photopath_g = null;
		} else {
			photopath_g = photoPath_g;
		}

		if (registerLabel_g.equals("null")) {
			regLabel_g = null;
		} else {
			regLabel_g = registerLabel_g;
		}

		if (registerIdentifier_g.equals("null")) {
			regIden_g = null;
		} else {
			regIden_g = registerIdentifier_g;
		}

		if (meterIdentifier_e.equals("null")) {
			meterIden_e = null;
		} else {
			meterIden_e = meterIdentifier_e;
		}

		if (meterIdentifier_g.equals("null")) {
			meterIden_g = null;
		} else {
			meterIden_g = meterIdentifier_g;
		}

		JSONObject reg1 = new JSONObject();
		reg1.put("readingValue", readingValue_e);
		reg1.put("registerLabel", regLabel_e);
		reg1.put("registerIdentifier", regIden_e);

		JSONObject reg2 = new JSONObject();
		reg2.put("readingValue", readingValue_g);
		reg2.put("registerLabel", regLabel_g);
		reg2.put("registerIdentifier", regIden_g);

		JSONArray regArray1 = new JSONArray();
		regArray1.add(reg1);
		JSONArray regArray2 = new JSONArray();
		regArray2.add(reg2);

		JSONObject cMeterReads1 = new JSONObject();
		cMeterReads1.put("meterpointId", meterpointId_e);
		cMeterReads1.put("meterIdentifier", meterIden_e);
		cMeterReads1.put("photoPath", photopath_e);
		cMeterReads1.put("photoSkipped", photoSkip_e);
		cMeterReads1.put("registers", regArray1);

		JSONObject cMeterReads2 = new JSONObject();
		cMeterReads2.put("meterpointId", meterpointId_g);
		cMeterReads2.put("meterIdentifier", meterIden_g);
		cMeterReads2.put("photoPath", photopath_g);
		cMeterReads2.put("registers", regArray2);

		JSONArray collectedMeterReads = new JSONArray();
		collectedMeterReads.add(cMeterReads1);
		collectedMeterReads.add(cMeterReads2);

		requestParams.put("memberId", memberId);
		requestParams.put("collectedMeterReads", collectedMeterReads);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointId_e, meterIdentifier_e, photoPath_e, photoSkipped_e, readingValue_ed, registerLabel_ed, registerIdentifier_ed, readingValue_en, registerLabel_en, registerIdentifier_en, meterpointId_g,meterIdentifier_g, photoPath_g, readingValue_g, registerLabel_g, registerIdentifier_g as (\\d+), \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_meterpointId_e_meterIdentifier_e_photoPath_e_photoSkipped_e_readingValue_ed_registerLabel_ed_registerIdentifier_ed_readingValue_en_registerLabel_en_registerIdentifier_en_meterpointId_g_meterIdentifier_g_photoPath_g_readingValue_g_registerLabel_g_registerIdentifier_g_as(int memberId, String meterpointId_e, String meterIdentifier_e, String photoPath_e, String photoSkipped_e, String readingValue_ed, String registerLabel_ed, String registerIdentifier_ed, String readingValue_en, String registerLabel_en, String registerIdentifier_en, String meterpointId_g, String meterIdentifier_g, String photoPath_g, String readingValue_g, String registerLabel_g, String registerIdentifier_g) throws Throwable 
	{
		String photopath_e;
		boolean photoSkip_e;
		String regLabel_ed;
		String regIden_ed;
		String regLabel_en;
		String regIden_en;
		String photopath_g;
		String regLabel_g;
		String regIden_g;
		String meterIden_e;
		String meterIden_g;


		if (photoPath_e.equals("null")) {
			photopath_e = null;
		} else {
			photopath_e = photoPath_e;
		}

		if (photoSkipped_e.equals("true")) {
			photoSkip_e = true;
		} else {
			photoSkip_e = false;
		}

		if (registerLabel_ed.equals("null")) {
			regLabel_ed = null;
		} else {
			regLabel_ed = registerLabel_ed;
		}

		if (registerIdentifier_ed.equals("null")) {
			regIden_ed = null;
		} else {
			regIden_ed = registerIdentifier_ed;
		}

		if (registerLabel_en.equals("null")) {
			regLabel_en = null;
		} else {
			regLabel_en = registerLabel_en;
		}

		if (registerIdentifier_en.equals("null")) {
			regIden_en = null;
		} else {
			regIden_en = registerIdentifier_en;
		}

		if (photoPath_g.equals("null")) {
			photopath_g = null;
		} else {
			photopath_g = photoPath_g;
		}

		if (registerLabel_g.equals("null")) {
			regLabel_g = null;
		} else {
			regLabel_g = registerLabel_g;
		}

		if (registerIdentifier_g.equals("null")) {
			regIden_g = null;
		} else {
			regIden_g = registerIdentifier_g;
		}

		if (meterIdentifier_e.equals("null")) {
			meterIden_e = null;
		} else {
			meterIden_e = meterIdentifier_e;
		}

		if (meterIdentifier_g.equals("null")) {
			meterIden_g = null;
		} else {
			meterIden_g = meterIdentifier_g;
		}

		JSONObject reg1d = new JSONObject();
		reg1d.put("readingValue", readingValue_ed);
		reg1d.put("registerLabel", regLabel_ed);
		reg1d.put("registerIdentifier", regIden_ed);

		JSONObject reg1n = new JSONObject();
		reg1n.put("readingValue", readingValue_en);
		reg1n.put("registerLabel", regLabel_en);
		reg1n.put("registerIdentifier", regIden_en);

		JSONObject reg2 = new JSONObject();
		reg2.put("readingValue", readingValue_g);
		reg2.put("registerLabel", regLabel_g);
		reg2.put("registerIdentifier", regIden_g);

		JSONArray regArray1 = new JSONArray();
		regArray1.add(reg1d);
		regArray1.add(reg1n);
		JSONArray regArray2 = new JSONArray();
		regArray2.add(reg2);

		JSONObject cMeterReads1 = new JSONObject();
		cMeterReads1.put("meterpointId", meterpointId_e);
		cMeterReads1.put("meterIdentifier", meterIden_e);
		cMeterReads1.put("photoPath", photopath_e);
		cMeterReads1.put("photoSkipped", photoSkip_e);
		cMeterReads1.put("registers", regArray1);

		JSONObject cMeterReads2 = new JSONObject();
		cMeterReads2.put("meterpointId", meterpointId_g);
		cMeterReads2.put("meterIdentifier", meterIden_g);
		cMeterReads2.put("photoPath", photopath_g);
		cMeterReads2.put("registers", regArray2);

		JSONArray collectedMeterReads = new JSONArray();
		collectedMeterReads.add(cMeterReads1);
		collectedMeterReads.add(cMeterReads2);

		requestParams.put("memberId", memberId);
		requestParams.put("collectedMeterReads", collectedMeterReads);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointId, meterIdentifier, photoPath, photoSkipped, readingValue, registerLabel, registerIdentifier as (\\d+), \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_meterpointId_meterIdentifier_photoPath_photoSkipped_readingValue_registerLabel_registerIdentifier_as(int memberId, String meterpointId, String meterIdentifier, String photoPath, String photoSkipped, String readingValue, String registerLabel, String registerIdentifier) throws Throwable 
	{
		String photopath;
		boolean photoSkip;
		String regLabel;
		String regIden;
		String meterIden;


		if (photoPath.equals("null")) {
			photopath = null;
		} else {
			photopath = photoPath;
		}

		if (photoSkipped.equals("true")) {
			photoSkip = true;
		} else {
			photoSkip = false;
		}

		if (registerLabel.equals("null")) {
			regLabel = null;
		} else {
			regLabel = registerLabel;
		}

		if (registerIdentifier.equals("null")) {
			regIden = null;
		} else {
			regIden = registerIdentifier;
		}

		if (meterIdentifier.equals("null")) {
			meterIden = null;
		} else {
			meterIden = meterIdentifier;
		}

		JSONObject reg1d = new JSONObject();
		reg1d.put("readingValue", readingValue);
		reg1d.put("registerLabel", regLabel);
		reg1d.put("registerIdentifier", regIden);

		JSONArray regArray1 = new JSONArray();
		regArray1.add(reg1d);

		JSONObject cMeterReads1 = new JSONObject();
		cMeterReads1.put("meterpointId", meterpointId);
		cMeterReads1.put("meterIdentifier", meterIden);
		cMeterReads1.put("photoPath", photopath);
		cMeterReads1.put("photoSkipped", photoSkip);
		cMeterReads1.put("registers", regArray1);

		JSONArray collectedMeterReads = new JSONArray();
		collectedMeterReads.add(cMeterReads1);

		requestParams.put("memberId", memberId);
		requestParams.put("collectedMeterReads", collectedMeterReads);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^memberId, meterpointId, meterIdentifier, photoPath, photoSkipped, readingValue_d, registerLabel_d, registerIdentifier_d, readingValue_n, registerLabel_n, registerIdentifier_n as (\\d+), \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_meterpointId_meterIdentifier_photoPath_photoSkipped_readingValue_d_registerLabel_d_registerIdentifier_d_readingValue_n_registerLabel_n_registerIdentifier_n_as(int memberId, String meterpointId, String meterIdentifier, String photoPath, String photoSkipped, String readingValue_d, String registerLabel_d, String registerIdentifier_d, String readingValue_n, String registerLabel_n, String registerIdentifier_n) throws Throwable 
	{
		String photopath;
		boolean photoSkip;
		String regLabel_d;
		String regIden_d;
		String regLabel_n;
		String regIden_n;
		String meterIden;


		if (photoPath.equals("null")) {
			photopath = null;
		} else {
			photopath = photoPath;
		}

		if (photoSkipped.equals("true")) {
			photoSkip = true;
		} else {
			photoSkip = false;
		}

		if (registerLabel_d.equals("null")) {
			regLabel_d = null;
		} else {
			regLabel_d = registerLabel_d;
		}

		if (registerIdentifier_d.equals("null")) {
			regIden_d = null;
		} else {
			regIden_d = registerIdentifier_d;
		}

		if (registerLabel_n.equals("null")) {
			regLabel_n = null;
		} else {
			regLabel_n = registerLabel_n;
		}

		if (registerIdentifier_n.equals("null")) {
			regIden_n = null;
		} else {
			regIden_n = registerIdentifier_n;
		}	

		if (meterIdentifier.equals("null")) {
			meterIden = null;
		} else {
			meterIden = meterIdentifier;
		}


		JSONObject reg1d = new JSONObject();
		reg1d.put("readingValue", readingValue_d);
		reg1d.put("registerLabel", regLabel_d);
		reg1d.put("registerIdentifier", regIden_d);

		JSONObject reg1n = new JSONObject();
		reg1n.put("readingValue", readingValue_n);
		reg1n.put("registerLabel", regLabel_n);
		reg1n.put("registerIdentifier", regIden_n);

		JSONArray regArray1 = new JSONArray();
		regArray1.add(reg1d);
		regArray1.add(reg1n);

		JSONObject cMeterReads1 = new JSONObject();
		cMeterReads1.put("meterpointId", meterpointId);
		cMeterReads1.put("meterIdentifier", meterIden);
		cMeterReads1.put("photoPath", photopath);
		cMeterReads1.put("photoSkipped", photoSkip);
		cMeterReads1.put("registers", regArray1);

		JSONArray collectedMeterReads = new JSONArray();
		collectedMeterReads.add(cMeterReads1);

		requestParams.put("memberId", memberId);
		requestParams.put("collectedMeterReads", collectedMeterReads);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}


	/*
	 * ******************************* Quick Quotes *****************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^quoteReference, quoteSource, createDate, firstName, lastName, emailAddress, postcode, mpans, tariffName, savingsAmountGBP, elecAnnualUsagekWhs, elecUnitRate, elecAnnualAmounIncMFGBP as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", (\\d+), (\\d+), (\\d+), (\\d+)$")
	public void quotereference_quoteSource_createDate_firstName_lastName_emailAddress_postcode_mpans_tariffName_savingsAmountGBP_elecAnnualUsagekWhs_elecUnitRate_elecAnnualAmounIncMFGBP_as(String quoteReference, String quoteSource, String createDate, String firstName, String lastName, String emailAddress, String postcode, String mpans, String tariffName, int savingsAmountGBP, int elecAnnualUsagekWhs, int elecUnitRate, int elecAnnualAmounIncMFGBP) throws Throwable 
	{
		this.email = emailAddress;
		requestParams.put("quoteReference", quoteReference);
		requestParams.put("quoteSource", quoteSource);
		requestParams.put("createDate", createDate);
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("emailAddress", emailAddress);
		requestParams.put("postcode", postcode);
		requestParams.put("mpans", mpans);
		requestParams.put("tariffName", tariffName);
		requestParams.put("savingsAmountGBP", savingsAmountGBP);
		requestParams.put("elecAnnualUsagekWhs", elecAnnualUsagekWhs);
		requestParams.put("elecUnitRate", elecUnitRate);
		requestParams.put("elecAnnualAmounIncMFGBP", elecAnnualAmounIncMFGBP);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^quoteReference, quoteSource, quoteReason, createDate, expiryDate, title, firstName, lastName, dateOfBirth, emailAddress, mobileNo, postcode, addressLine, productType, mpans, mprns, selectedMeterType, tariffName, savingsAmountGBP, annualQuoteAmountGBP, minAnnualQuoteAmountGBP, elecAnnualUsagekWhs, elecUnitRate, elecAnnualAmounIncMFGBP, gasAnnualUsagekWhs, gasUnitRate, gasAnnualAmountIncMFGBP, discountCode, discountApplied as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+),\"([^\"]*)\", \"([^\"]*)\"$")
	public void quotereference_quoteSource_quoteReason_createDate_expiryDate_title_firstName_lastName_dateOfBirth_emailAddress_mobileNo_postcode_addressLine_productType_mpans_mprns_selectedMeterType_tariffName_savingsAmountGBP_annualQuoteAmountGBP_minAnnualQuoteAmountGBP_elecAnnualUsagekWhs_elecUnitRate_elecAnnualAmounIncMFGBP_gasAnnualUsagekWhs_gasUnitRate_gasAnnualAmountIncMFGBP_discountCode_discountApplied_as(String quoteReference, String quoteSource, String quoteReason, String createDate, String expiryDate, String title, String firstName, String lastName, String dateOfBirth, String emailAddress, String mobileNo, String postcode, String addressLine, String productType, String mpans, String mprns, String selectedMeterType, String tariffName, int savingsAmountGBP, int annualQuoteAmountGBP, int minAnnualQuoteAmountGBP, int elecAnnualUsagekWhs, int elecUnitRate, int elecAnnualAmounIncMFGBP, int gasAnnualUsagekWhs, int gasUnitRate, int gasAnnualAmountIncMFGBP, String discountCode, String discountApplied) throws Throwable 
	{
		this.email = emailAddress;
		requestParams.put("quoteReference", quoteReference);
		requestParams.put("quoteSource", quoteSource);
		requestParams.put("quoteReason", quoteReason);
		requestParams.put("createDate", createDate);
		requestParams.put("expiryDate", expiryDate);
		requestParams.put("title", title);
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("dateOfBirth", dateOfBirth);
		requestParams.put("emailAddress", emailAddress);
		requestParams.put("mobileNo", mobileNo);
		requestParams.put("postcode", postcode);
		requestParams.put("addressLine", addressLine);
		requestParams.put("productType", productType);
		requestParams.put("mpans", mpans);
		requestParams.put("mprns", mprns);
		requestParams.put("selectedMeterType", selectedMeterType);
		requestParams.put("tariffName", tariffName);
		requestParams.put("savingsAmountGBP", savingsAmountGBP);
		requestParams.put("annualQuoteAmountGBP", annualQuoteAmountGBP);
		requestParams.put("minAnnualQuoteAmountGBP", minAnnualQuoteAmountGBP);
		requestParams.put("elecAnnualUsagekWhs", elecAnnualUsagekWhs);
		requestParams.put("elecUnitRate", elecUnitRate);
		requestParams.put("elecAnnualAmounIncMFGBP", elecAnnualAmounIncMFGBP);
		requestParams.put("gasAnnualUsagekWhs", gasAnnualUsagekWhs);
		requestParams.put("gasUnitRate", gasUnitRate);
		requestParams.put("gasAnnualAmountIncMFGBP", gasAnnualAmountIncMFGBP);	
		requestParams.put("discountCode", discountCode);
		requestParams.put("discountApplied", discountApplied);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 * *********************** Save Quotes ********************
	 */

	@SuppressWarnings("unchecked")
	@Given("^all the request parameters of save quotes are passed as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\", (\\d+), (\\d+), (\\d+), (\\d+), \"([^\"]*)\", (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void all_the_request_parameters_of_save_quotes_are_passed_as(String addressLine, String postcode, String productType, String referenceProductType, String selectedMeterType, String referenceMeterType, String mpans, String mprns, String quoteReason, String quoteSource, int quoteReference, String quoteDatetime, String tariffName, int savingAmountGBP, int carbonSavingskg, int annualQuoteAmountGBP, int minAnnualQuoteAmountGBP, String comparisonSupplier, int elecAnnualUsagekWhs, int elecUnitRate, int elecAnnualAmounIncMFGBP, int elecAnnualAmountExcMFGBP, int elecMonthlyMembershipFeeGBP, int elecAnnualMembershipFeeGBP, int gasAnnualUsagekWhs, int gasUnitRate, int gasAnnualAmountIncMFGBP, int gasAnnualAmountExcMFGBP, int gasMonthlyMembershipFeeGBP, int gasAnnualMembershipFeeGBP, int summerMonthDDAmountGBP, int minSummerMonthDDAmountGBP, int winterMonthDDAmountGBP, int minWinterMonthDDAmountGBP, String discountCode, String discountType, int discountAmount, String discountApplied, String expiryDateTime, String verifyDeeplinkURL) throws Throwable 
	{
		JSONArray mpan= new JSONArray();
		mpan.add(mpans);

		JSONArray mprn = new JSONArray();
		mprn.add(mprns);

		JSONArray summerMonths = new JSONArray();
		summerMonths.add(4);
		summerMonths.add(5);
		summerMonths.add(6);
		summerMonths.add(7);
		summerMonths.add(8);
		summerMonths.add(9);

		JSONArray winterMonths = new JSONArray();
		winterMonths.add(10);
		winterMonths.add(11);
		winterMonths.add(12);
		winterMonths.add(1);
		winterMonths.add(2);
		winterMonths.add(3);

		requestParams.put("addressLine", addressLine);
		requestParams.put("postcode", postcode);
		requestParams.put("productType", productType);
		requestParams.put("referenceProductType", referenceProductType);
		requestParams.put("selectedMeterType", selectedMeterType);
		requestParams.put("referenceMeterType", referenceMeterType);
		requestParams.put("mpans", mpan);
		requestParams.put("mprns", mprn);
		requestParams.put("quoteReason",quoteReason);
		requestParams.put("quoteSource", quoteSource);
		requestParams.put("quoteReference", quoteReference);
		requestParams.put("quoteDatetime", quoteDatetime);
		requestParams.put("tariffName", tariffName);
		requestParams.put("savingAmountGBP", savingAmountGBP);
		requestParams.put("carbonSavingskg", carbonSavingskg);
		requestParams.put("annualQuoteAmountGBP", annualQuoteAmountGBP);
		requestParams.put("minAnnualQuoteAmountGBP", minAnnualQuoteAmountGBP);
		requestParams.put("comparisonSupplier", comparisonSupplier);
		requestParams.put("elecAnnualUsagekWhs", elecAnnualUsagekWhs);
		requestParams.put("elecUnitRate", elecUnitRate);
		requestParams.put("elecAnnualAmounIncMFGBP", elecAnnualAmounIncMFGBP);
		requestParams.put("elecAnnualAmountExcMFGBP", elecAnnualAmountExcMFGBP);
		requestParams.put("elecMonthlyMembershipFeeGBP", elecMonthlyMembershipFeeGBP);
		requestParams.put("elecAnnualMembershipFeeGBP", elecAnnualMembershipFeeGBP);
		requestParams.put("gasAnnualUsagekWhs", gasAnnualUsagekWhs);
		requestParams.put("gasUnitRate", gasUnitRate);
		requestParams.put("gasAnnualAmountIncMFGBP", gasAnnualAmountIncMFGBP);
		requestParams.put("gasAnnualAmountExcMFGBP", gasAnnualAmountExcMFGBP);
		requestParams.put("gasMonthlyMembershipFeeGBP", gasMonthlyMembershipFeeGBP);
		requestParams.put("gasAnnualMembershipFeeGBP", gasAnnualMembershipFeeGBP);
		requestParams.put("summerMonths", summerMonths);
		requestParams.put("summerMonthDDAmountGBP", summerMonthDDAmountGBP);
		requestParams.put("minSummerMonthDDAmountGBP", minSummerMonthDDAmountGBP);
		requestParams.put("winterMonths", winterMonths);
		requestParams.put("winterMonthDDAmountGBP", winterMonthDDAmountGBP);
		requestParams.put("minWinterMonthDDAmountGBP", minWinterMonthDDAmountGBP);
		requestParams.put("discountCode", discountCode);
		requestParams.put("discountType", discountType);
		requestParams.put("discountAmount", discountAmount);
		requestParams.put("discountApplied", discountApplied);
		requestParams.put("expiryDateTime", expiryDateTime);
		requestParams.put("verifyDeeplinkURL", verifyDeeplinkURL);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^request parameters for productType Elec are passed as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", (\\d+), \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), (\\d+), \"([^\"]*)\", \"([^\"]*)\"$")
	public void request_parameters_for_productType_Elec_are_passed_as(String addressLine, String postcode, String productType, String referenceProductType, String selectedMeterType, String referenceMeterType, String mpans, String mprns, String quoteReason, int quoteReference, String quoteDatetime, String tariffName, String comparisonSupplier, int savingAmountGBP, int carbonSavingskg, int annualQuoteAmountGBP, int minAnnualQuoteAmountGBP, int elecAnnualUsagekWhs, int elecUnitRate, int elecAnnualAmounIncMFGBP, int elecAnnualAmountExcMFGBP, int elecMonthlyMembershipFeeGBP, int elecAnnualMembershipFeeGBP, int summerMonthDDAmountGBP, int minSummerMonthDDAmountGBP, int winterMonthDDAmountGBP, int minWinterMonthDDAmountGBP, String expiryDateTime, String verifyDeeplinkURL) throws Throwable 
	{
		JSONArray mpan= new JSONArray();
		mpan.add(mpans);

		JSONArray mprn = new JSONArray();
		mprn.add(mprns);

		JSONArray summerMonths = new JSONArray();
		summerMonths.add(4);
		summerMonths.add(5);
		summerMonths.add(6);
		summerMonths.add(7);
		summerMonths.add(8);
		summerMonths.add(9);

		JSONArray winterMonths = new JSONArray();
		winterMonths.add(10);
		winterMonths.add(11);
		winterMonths.add(12);
		winterMonths.add(1);
		winterMonths.add(2);
		winterMonths.add(3);

		requestParams.put("addressLine", addressLine);
		requestParams.put("postcode", postcode);
		requestParams.put("productType", productType);
		requestParams.put("referenceProductType", referenceProductType);
		requestParams.put("selectedMeterType", selectedMeterType);
		requestParams.put("referenceMeterType", referenceMeterType);
		requestParams.put("mpans", mpan);
		requestParams.put("mprns", mprn);
		requestParams.put("quoteReason", quoteReason);
		requestParams.put("quoteReference", quoteReference);
		requestParams.put("quoteDatetime", quoteDatetime);
		requestParams.put("tariffName", tariffName);
		requestParams.put("comparisonSupplier", comparisonSupplier);
		requestParams.put("savingAmountGBP", savingAmountGBP);
		requestParams.put("carbonSavingskg", carbonSavingskg);
		requestParams.put("annualQuoteAmountGBP", annualQuoteAmountGBP);
		requestParams.put("minAnnualQuoteAmountGBP", minAnnualQuoteAmountGBP);
		requestParams.put("elecAnnualUsagekWhs", elecAnnualUsagekWhs);
		requestParams.put("elecUnitRate", elecUnitRate);
		requestParams.put("elecAnnualAmounIncMFGBP", elecAnnualAmounIncMFGBP);
		requestParams.put("elecAnnualAmountExcMFGBP", elecAnnualAmountExcMFGBP);
		requestParams.put("elecMonthlyMembershipFeeGBP", elecMonthlyMembershipFeeGBP);
		requestParams.put("elecAnnualMembershipFeeGBP", elecAnnualMembershipFeeGBP);
		requestParams.put("summerMonths", summerMonths);
		requestParams.put("summerMonthDDAmountGBP", summerMonthDDAmountGBP);
		requestParams.put("minSummerMonthDDAmountGBP", minSummerMonthDDAmountGBP);
		requestParams.put("winterMonths", winterMonths);
		requestParams.put("winterMonthDDAmountGBP", winterMonthDDAmountGBP);
		requestParams.put("minWinterMonthDDAmountGBP", minWinterMonthDDAmountGBP);
		requestParams.put("expiryDateTime", expiryDateTime);
		requestParams.put("verifyDeeplinkURL", verifyDeeplinkURL);

		RequestSpecification request =  RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 * ****************************** Case *****************************
	 */

	@SuppressWarnings("unchecked")
	@Given("^memberId, recordType, status, caseType, type as (\\d+), \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void memberid_recordType_status_caseType_type_as(int memberId, String recordType, String status, String caseType, String type) throws Throwable 
	{
		requestParams.put("memberId", memberId);
		requestParams.put("recordType", recordType);
		requestParams.put("status", status);
		requestParams.put("caseType", caseType);
		requestParams.put("type", type);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^name, email, phone, recordType, subject, description, priority, originator, status, caseType, type, reason, preferredContactTime as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void name_email_phone_recordType_subject_description_priority_originator_status_caseType_type_reason_preferredContactTime_as(String name, String email, String phone, String recordType, String subject, String description, String priority, String originator, String status, String caseType, String type, String reason, String preferredContactTime) throws Throwable 
	{
		requestParams.put("name", name);
		requestParams.put("email", email);
		requestParams.put("phone", phone);
		requestParams.put("recordType", recordType);
		requestParams.put("subject", subject);
		requestParams.put("description", description);
		requestParams.put("priority", priority);
		requestParams.put("originator", originator);
		requestParams.put("status", status);
		requestParams.put("caseType", caseType);
		requestParams.put("type", type);
		requestParams.put("reason", reason);
		requestParams.put("preferredContactTime", preferredContactTime);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^recordType, subject, description, priority, originator, status, caseType, type, reason, preferredContactTime as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void recordtype_subject_description_priority_originator_status_caseType_type_reason_preferredContactTime_as(String recordType, String subject, String description, String priority, String originator, String status, String caseType, String type, String reason, String preferredContactTime) throws Throwable 
	{
		requestParams.put("recordType", recordType);
		requestParams.put("subject", subject);
		requestParams.put("description", description);
		requestParams.put("priority", priority);
		requestParams.put("originator", originator);
		requestParams.put("status", status);
		requestParams.put("caseType", caseType);
		requestParams.put("type", type);
		requestParams.put("reason", reason);
		requestParams.put("preferredContactTime", preferredContactTime);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^leadId, recordType, subject, description, priority, originator, status, caseType, type, reason, preferredContactTime as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void leadid_recordType_subject_description_priority_originator_status_caseType_type_reason_preferredContactTime_as(String leadId, String recordType, String subject, String description, String priority, String originator, String status, String caseType, String type, String reason, String preferredContactTime) throws Throwable 
	{
		requestParams.put("leadId", leadId);
		requestParams.put("recordType", recordType);
		requestParams.put("subject", subject);
		requestParams.put("description", description);
		requestParams.put("priority", priority);
		requestParams.put("originator", originator);
		requestParams.put("status", status);
		requestParams.put("caseType", caseType);
		requestParams.put("type", type);
		requestParams.put("reason", reason);
		requestParams.put("preferredContactTime", preferredContactTime);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^accountId, recordType, subject, description, priority, originator, status, caseType, type, reason, preferredContactTime as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void accountid_recordType_subject_description_priority_originator_status_caseType_type_reason_preferredContactTime_as(String accountId, String recordType, String subject, String description, String priority, String originator, String status, String caseType, String type, String reason, String preferredContactTime) throws Throwable 
	{
		requestParams.put("accountId", accountId);
		requestParams.put("recordType", recordType);
		requestParams.put("subject", subject);
		requestParams.put("description", description);
		requestParams.put("priority", priority);
		requestParams.put("originator", originator);
		requestParams.put("status", status);
		requestParams.put("caseType", caseType);
		requestParams.put("type", type);
		requestParams.put("reason", reason);
		requestParams.put("preferredContactTime", preferredContactTime);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^contactId, recordType, subject, description, priority, originator, status, caseType, type, reason, preferredContactTime as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void contactid_recordType_subject_description_priority_originator_status_caseType_type_reason_preferredContactTime_as(String contactId, String recordType, String subject, String description, String priority, String originator, String status, String caseType, String type, String reason, String preferredContactTime) throws Throwable 
	{
		requestParams.put("contactId", contactId);
		requestParams.put("recordType", recordType);
		requestParams.put("subject", subject);
		requestParams.put("description", description);
		requestParams.put("priority", priority);
		requestParams.put("originator", originator);
		requestParams.put("status", status);
		requestParams.put("caseType", caseType);
		requestParams.put("type", type);
		requestParams.put("reason", reason);
		requestParams.put("preferredContactTime", preferredContactTime);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	/*
	 ********************** No Header Parameters ***************************
	 */


	@When("^header parameters are not passed GET$")
	public void header_parameters_are_not_passed_GET() throws Throwable 
	{
		req.header("Content-Type","application/json");
		response = req.relaxedHTTPSValidation().get(FinalUrl);

		response.prettyPrint();
		System.out.println();
	}

	@When("^header parameters are not passed POST to url \"([^\"]*)\"$")
	public void header_parameters_are_not_passed_POST_to_url(String url) throws Throwable 
	{
		String Baseurl = url;
		req.header("Content-Type","application/json");
		response = req.relaxedHTTPSValidation().post(Baseurl);

		response.prettyPrint();
		System.out.println();
	}


	@When("^header parameters are not passed PUT$")
	public void header_parameters_are_not_passed_PUT() throws Throwable 
	{
		String Baseurl = FinalUrl;
		req.header("Content-Type","application/json");
		System.out.println("Base Url"+ Baseurl);
		response = req.relaxedHTTPSValidation().put(Baseurl);
		//Response response = req.put(Baseurl);
		System.out.println("response: " + response.prettyPrint());

	}
	
	/*
	 * ************************ Replay ***************************
	 */
	
	@SuppressWarnings("unchecked")
	@Given("^accountId as \"([^\"]*)\"$")
	public void accountid_as(String accountId) throws Throwable 
	{
		requestParams.put("accountId", accountId);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		
	}

	
	/*
	 * ********************* MI PUT Links **********************
	 */
	
	@SuppressWarnings("unchecked")
	@Given("^LeadId is passed as \"([^\"]*)\"$")
	public void leadid_is_passed_as(String LeadId) throws Throwable 
	{
		JSONObject identifier = new JSONObject();
		identifier.put("referTo", "CRM-LeadId");
		identifier.put("systemId", LeadId);
		
		JSONArray iden = new JSONArray();
		iden.add(identifier);
		
		JSONObject links = new JSONObject();
		links.put("identifiers", iden);
		
		JSONArray linksArr = new JSONArray();
		linksArr.add(links);
		
		requestParams.put("links", linksArr);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
	}

	@SuppressWarnings("unchecked")
	@Given("^AccountId is passed as \"([^\"]*)\"$")
	public void accountid_is_passed_as(String AccountId) throws Throwable 
	{
		JSONObject identifier = new JSONObject();
		identifier.put("referTo", "CRM-AccountId");
		identifier.put("systemId", AccountId);
		
		JSONArray iden = new JSONArray();
		iden.add(identifier);
		
		JSONObject links = new JSONObject();
		links.put("identifiers", iden);
		
		JSONArray linksArr = new JSONArray();
		linksArr.add(links);
		
		requestParams.put("links", linksArr);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	@SuppressWarnings("unchecked")
	@Given("^ContactId is passed as \"([^\"]*)\"$")
	public void contactid_is_passed_as(String ContactId) throws Throwable 
	{
		JSONObject identifier = new JSONObject();
		identifier.put("referTo", "CRM-ContactId");
		identifier.put("systemId", ContactId);
		
		JSONArray iden = new JSONArray();
		iden.add(identifier);
		
		JSONObject links = new JSONObject();
		links.put("identifiers", iden);
		
		JSONArray linksArr = new JSONArray();
		linksArr.add(links);
		
		requestParams.put("links", linksArr);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

	@SuppressWarnings("unchecked")
	@Given("^Billing-CustomerId is passed as \"([^\"]*)\"$")
	public void billing_CustomerId_is_passed_as(String Billing_CustomerId) throws Throwable 
	{
		JSONObject identifier = new JSONObject();
		identifier.put("referTo", "Billing-CustomerId");
		identifier.put("systemId", Billing_CustomerId);
		
		JSONArray iden = new JSONArray();
		iden.add(identifier);
		
		JSONObject links = new JSONObject();
		links.put("identifiers", iden);
		
		JSONArray linksArr = new JSONArray();
		linksArr.add(links);
		
		requestParams.put("links", linksArr);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());

	}

}
