package stepDefinition;


public class Address 
{/*
	Response response;
	RequestSpecification req;
	String FinalUrl;
	String postCode;
	
	@Given("^Postcode as \"([^\"]*)\" and url as \"([^\"]*)\"$")
	public void postcode_as_and_url_as(String postCode, String url) throws Throwable 
	{
		req = given().param("postcode:" + postCode);
		FinalUrl = url.concat("/"+postCode);
		System.out.println(FinalUrl);
		this.postCode = postCode;
		
	}

	@When("^address details are retrieved$")
	public void address_details_are_retrieved() throws Throwable {
	    // pass header parameters
		req.header("Content-Type","application/json");
		req.header("Device-Advertising-ID","dai");
		req.header("Device-Notification-ID","dni");
		req.header("Device-Type","Android");
		req.header("Client-Id","App");
		req.header("Pure-Tracking-Id","pureId");
		response = req.relaxedHTTPSValidation().get(FinalUrl);
		
		response.prettyPrint();
		
		System.setOut(new PrintStream(new FileOutputStream("D:/Apoorva/Pure Energy/RRL/eclipse responses/Address/Address_"+GenericMethods.date()+"_"+postCode+".txt")));
	}*/
}
