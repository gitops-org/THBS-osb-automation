package stepDefinition;


public class MI_POST_sd 
{
	/*private RequestSpecification req;
	private Response response;

	@SuppressWarnings("unchecked")
	@Given("^firstName, lastName and email as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void firstname_lastName_and_email_as(String firstName, String lastName, String email) throws Throwable {
		JSONObject requestParams = new JSONObject();
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		System.out.println(req);
	}

	@SuppressWarnings("unchecked")
	@Given("^all the request parameters are passed as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void all_the_request_parameters_are_passed_as(String title, String firstName, String lastName, String email, String mobile, String dob, String refCode, String refSource, String refEmail) throws Throwable {
		JSONObject requestParams = new JSONObject();
		requestParams.put("title", title);
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		requestParams.put("mobile", mobile);
		requestParams.put("dateOfBirth", dob);
		requestParams.put("referralCode", refCode);
		requestParams.put("referralSource", refSource);
		requestParams.put("referralEmail", refEmail);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());


	}

	@SuppressWarnings("unchecked")
	@Given("^title, firstName, lastName,email, mobile and dob as \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void title_firstName_lastName_email_mobile_and_dob_as(String title, String firstName, String lastName, String email, String mobile, String dob) throws Throwable {
		JSONObject requestParams = new JSONObject();
		requestParams.put("title", title);
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		requestParams.put("mobile", mobile);
		requestParams.put("dateOfBirth", dob);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		System.out.println(req);
	}

	@SuppressWarnings("unchecked")
	@Given("^firstName, lastName, email, referralCode, referralSource and referralEmail as  \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void firstname_lastName_email_referralCode_referralSource_and_referralEmail_as(String firstName, String lastName, String email, String refCode, String refSource, String refEmail) throws Throwable {
		JSONObject requestParams = new JSONObject();
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		requestParams.put("referralCode", refCode);
		requestParams.put("referralSource", refSource);
		requestParams.put("referralEmail", refEmail);

		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		System.out.println(req);
	}

	/*
	@Given("^request body is set to \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void request_body_is_set_to(String firstName, String lastName, String email) throws Throwable 
	{
		JSONObject requestParams = new JSONObject();
		requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		System.out.println(req);
		//throw new PendingException();

	}
	 */
	/*
	@When("^request is POSTed to url \"([^\"]*)\"$")
	public void request_is_POSTed_to_url(String url) throws Throwable {
		String Baseurl = url;
		/*req.header("Content-Type","application/json");
		req.header("Device-Advertising-ID","dai");
		req.header("Device-Notification-ID","dni");
		req.header("Device-Type","Android");
		req.header("Client-Id","App");
		req.header("Pure-Tracking-Id","pureId");
		System.out.println("baseUrl: "+Baseurl);
		Response response = req.post(Baseurl);
		System.out.println("response: " + response.prettyPrint());


	}*/
	/*
	@When("^i POST request$")
	public void i_POST_request() throws Throwable {
		//RestAssured.baseURI ="http://52.213.194.179:8280/v1/member-identities/";
		String Baseurl = "http://52.213.194.179:8280/v1/member-identities/";
		req.header("Content-Type","application/json");
		req.header("Device-Advertising-ID","dai");
		req.header("Device-Notification-ID","dni");
		req.header("Device-Type","Android");
		req.header("Client-Id","App");
		req.header("Pure-Tracking-Id","MI_POST");
		Response response = req.post(Baseurl);
		System.out.println("response: " + response.prettyPrint());

		//throw new PendingException();
}

	@Then("^response code should be (\\d+)$")
	public void response_code_should_be(int statusCode) throws Throwable {
		//int respStatusCode =  response.getStatusCode();
		int respStatusCode = 200;
		if(statusCode == respStatusCode)
		{
			System.out.println("Test case status: Pass");
		}
		else
		{
			System.out.println("Test case status: Fail");
		}
		//throw new PendingException();
	}*/

}
