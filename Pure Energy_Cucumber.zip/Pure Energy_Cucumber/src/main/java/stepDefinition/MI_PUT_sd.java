package stepDefinition;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class MI_PUT_sd {

	private RequestSpecification req;
	private Response response;
}
