package stepDefinition;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class MI_Login 
{
	private RequestSpecification req;
	public String FinalUrl;
	public String email;
	Response resp;
	/*@SuppressWarnings("unchecked")
	@Given("^verify url is passed as \"([^\"]*)\"$")
	public void verify_url_is_passed_as(String verifyUrl) throws Throwable 
	{
		JSONObject requestParams = new JSONObject();
		requestParams.put("verifyUrl", verifyUrl);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		
	}

	@SuppressWarnings("unchecked")
	@Given("^verify url and reason is passed as \"([^\"]*)\",\"([^\"]*)\"$")
	public void verify_url_and_reason_is_passed_as(String verifyUrl, String reason) throws Throwable 
	{
		JSONObject requestParams = new JSONObject();
		requestParams.put("verifyUrl", verifyUrl);
		requestParams.put("reason", reason);
		RequestSpecification request = RestAssured.given();
		req = request.body(requestParams.toJSONString());
		
	}
	
	@Given("^email is passed as \"([^\"]*)\"$")
	public void email_is_passed_as(String email) throws Throwable 
	{
		this.email = email;
	}

	@When("^posted to url \"([^\"]*)\"$")
	public void posted_to_url(String url) throws Throwable 
	{
		FinalUrl = url.concat("/"+email+"/login");
		resp = req.post(FinalUrl);
		System.out.println("final url:"+url);
		
	}*/
	


}
