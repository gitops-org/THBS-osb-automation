package responseComparision;

import cucumberTest.GenericMethods;

public class RetrieveQuotes extends GenericMethods
{
	public void setExpectedResponse(String path, String sheetName, int row)
	{
		Exp_memberId = getIntValues(path, sheetName, row, 0);
		Exp_addressLine = getStringValues(path, sheetName, row, 1);
		Exp_postcode = getStringValues(path, sheetName, row, 2) ;
		Exp_productType = getStringValues(path, sheetName, row, 3);
		Exp_mpans = getStringValues(path, sheetName, row, 4);
		Exp_mprns = getStringValues(path, sheetName, row, 5);
		Exp_quoteReason = getStringValues(path, sheetName, row, 6);
		Exp_quoteReference = getIntValues(path, sheetName, row, 7);
		Exp_tariffName = getStringValues(path, sheetName, row, 8);
		Exp_savingAmountGBP = getDoubleValues(path, sheetName, row, 9);
		Exp_carbonSavingskg = getDoubleValues(path, sheetName, row, 10);
		Exp_annualQuoteAmountGBP = getDoubleValues(path, sheetName, row, 11);
		Exp_minAnnualQuoteAmountGBP = getDoubleValues(path, sheetName, row, 12);
		Exp_comparisionSupplier = getStringValues(path, sheetName, row, 13);
		Exp_elecAnnualUsagekWhs = getDoubleValues(path, sheetName, row, 14);
		Exp_elecUnitRate = getDoubleValues(path, sheetName, row, 15);
		Exp_elecAnnualAmounIncMFGBP = getDoubleValues(path, sheetName, row, 16);
		Exp_elecAnnualAmountExcMFGBP = getDoubleValues(path, sheetName, row, 17);
		Exp_elecMonthlyMembershipFeeGBP = getDoubleValues(path, sheetName, row, 18);
		Exp_elecAnnualMembershipFeeGBP = getDoubleValues(path, sheetName, row, 19);
		Exp_gasAnnualUsagekWhs = getDoubleValues(path, sheetName, row, 20);
		Exp_gasUnitRate = getDoubleValues(path, sheetName, row, 21);
		Exp_gasAnnualAmountIncMFGBP = getDoubleValues(path, sheetName, row, 22);
		Exp_gasAnnualAmountExcMFGBP = getDoubleValues(path, sheetName, row, 23);
		Exp_gasMonthlyMembershipFeeGBP = getDoubleValues(path, sheetName, row, 24);
		Exp_gasAnnualMembershipFeeGBP = getDoubleValues(path, sheetName, row, 25);
		Exp_expiryDateTime = getStringValues(path, sheetName, row, 26);
		
	}
	
	public void compareResponse_Dual(int memberId, String addressLine, String postcode, String productType, String mpans, String mprns, String quoteReason, int quoteReference, String tariffName , double savingAmountGBP, double carbonSavingskg, double annualQuoteAmountGBP, double minAnnualQuoteAmountGBP, String comparisonSupplier,double elecAnnualUsagekWhs, double elecUnitRate, double elecAnnualAmounIncMFGBP, double elecAnnualAmountExcMFGBP, double elecMonthlyMembershipFeeGBP, double elecAnnualMembershipFeeGBP, double gasAnnualUsagekWhs, double gasUnitRate, double gasAnnualAmountIncMFGBP, double gasAnnualAmountExcMFGBP, double gasMonthlyMembershipFeeGBP, double gasAnnualMembershipFeeGBP, String expiryDateTime )
	{
		boolean status = true;
		if (!(memberId == Exp_memberId))
		{
			System.out.println("MemberId returned is invalid");
			status = false;
		}
		if (!(addressLine.equals(Exp_addressLine))) 
		{
			System.out.println("addressLine returned is invalid");
			status = false;
		}
		if (!(postcode.equals(Exp_postcode))) 
		{
			System.out.println("postcode returned is invalid");
			status = false;
		}
		if (!(productType.equals(Exp_productType))) 
		{
			System.out.println("productType returned is invalid");
			status = false;
		}
		if (!(mpans.equals(Exp_mpans))) 
		{
			System.out.println("mpan returned is invalid");
			status = false;
		}
		if (!(mprns.equals(Exp_mprns))) 
		{
			System.out.println("mprn returned is invalid");
			status = false;
		}
		if (!(quoteReason.equals(Exp_quoteReason))) 
		{
			System.out.println("Quote reason returned is invalid");
			status = false;
		}
		if (!(quoteReference == Exp_quoteReference)) 
		{
			System.out.println("Quote reference returned is invalid");
			status = false;
		}
		if (!(tariffName.equals(Exp_tariffName))) 
		{
			System.out.println("Tariff name returned is invalid");
			status = false;
		}
		if (!(savingAmountGBP == Exp_savingAmountGBP)) 
		{
			System.out.println("SavingAmountGBP returned is invalid");
			status = false;
		}
		if (!(carbonSavingskg == Exp_carbonSavingskg)) 
		{
			System.out.println("CarbonSavingsKg returned is invalid");
			status = false;
		}
		if (!(annualQuoteAmountGBP == Exp_annualQuoteAmountGBP)) 
		{
			System.out.println("annualQuoteAmountGBP returned is invalid");
			status = false;
		}
		if (!(minAnnualQuoteAmountGBP == Exp_minAnnualQuoteAmountGBP)) 
		{
			System.out.println("minAnnualQuoteAmountGBP returned is invalid");
			status = false;
		}
		if (!(comparisonSupplier.equals(Exp_comparisionSupplier)))
		{
			System.out.println("comparisonSupplier returned is invalid");
			status = false;
		}
		if (!(elecAnnualUsagekWhs == Exp_elecAnnualUsagekWhs)) 
		{
			System.out.println("elecAnnualUsagekWhs returned is invalid");
			status = false;
		}
		if (!(elecUnitRate == Exp_elecUnitRate)) 
		{
			System.out.println("elecUnitRate returned is invalid");
			status = false;
		}
		if (!(elecAnnualAmounIncMFGBP == Exp_elecAnnualAmounIncMFGBP)) 
		{
			System.out.println("elecAnnualAmounIncMFGBP returned id invalid");
			status = false;
		}
		if (!(elecAnnualAmountExcMFGBP == Exp_elecAnnualAmountExcMFGBP)) 
		{
			System.out.println("elecAnnualAmountExcMFGBP returned is invalid");
			status = false;
		}
		if (!(elecMonthlyMembershipFeeGBP == Exp_elecMonthlyMembershipFeeGBP)) 
		{
			System.out.println("elecMonthlyMembershipFeeGBP returned is invalid");
			status = false;
		}
		if (!(elecAnnualMembershipFeeGBP == Exp_elecAnnualMembershipFeeGBP)) 
		{
			System.out.println("elecAnnualMembershipFeeGBP returned is invalid");
			status = false;
		}
		if (!(gasAnnualUsagekWhs == Exp_gasAnnualUsagekWhs)) 
		{
			System.out.println("gasAnnualUsagekWhs returned is invalid");
			status = false;
		}
		if (!(gasUnitRate == Exp_gasUnitRate)) 
		{
			System.out.println("gasUnitRate returned is invalid");
			status = false;
		}
		if (!(gasAnnualAmountIncMFGBP == Exp_gasAnnualAmountIncMFGBP)) 
		{
			System.out.println("gasAnnualAmountIncMFGBP returned is invalid");
			status = false;
		}
		if (!(gasAnnualAmountExcMFGBP == Exp_gasAnnualAmountExcMFGBP)) 
		{
			System.out.println("gasAnnualAmountExcMFGBP returned is invalid");
			status = false;
		}
		if (!(gasAnnualMembershipFeeGBP == Exp_gasAnnualMembershipFeeGBP)) 
		{
			System.out.println("gasMonthlyMembershipFeeGBP returned is invalid");
			status = false;
		}
		if (!(gasAnnualMembershipFeeGBP == Exp_gasAnnualMembershipFeeGBP)) 
		{
			System.out.println("gasAnnualMembershipFeeGBP returned is invalid");
			status = false;
		}
		if (!(expiryDateTime == null && Exp_expiryDateTime.equals("null")||(expiryDateTime.equals("Exp_expiryDateTime"))))
		{
			System.out.println("expiryDateTime returned is invalid");
			status = false;
		}
		if (status) 
		{
			System.out.println("All the response parameters are verified");
		}
		else
		{
			System.out.println("Response returned is not as expected");
		}

	}
	
	public void compareResponse_Elec(int memberId, String addressLine, String postcode, String productType, String mpans, String mprns, String quoteReason, int quoteReference, String tariffName , double savingAmountGBP, double carbonSavingskg, double annualQuoteAmountGBP, double minAnnualQuoteAmountGBP, String comparisonSupplier,double elecAnnualUsagekWhs, double elecUnitRate, double elecAnnualAmounIncMFGBP, double elecAnnualAmountExcMFGBP, double elecMonthlyMembershipFeeGBP, double elecAnnualMembershipFeeGBP, String expiryDateTime )
	{
		boolean status = true;
		if (!(memberId == Exp_memberId))
		{
			System.out.println("MemberId returned is invalid");
			status = false;
		}
		if (!(addressLine.equals(Exp_addressLine))) 
		{
			System.out.println("addressLine returned is invalid");
			status = false;
		}
		if (!(postcode.equals(Exp_postcode))) 
		{
			System.out.println("postcode returned is invalid");
			status = false;
		}
		if (!(productType.equals(Exp_productType))) 
		{
			System.out.println("productType returned is invalid");
			status = false;
		}
		if (!(mpans.equals(Exp_mpans))) 
		{
			System.out.println("mpan being compared is: "+mpans);
			System.out.println("mpan returned is invalid");
			status = false;
		}
		if (!(mprns == null && Exp_mprns.equals("null")||(mprns.equals(Exp_mprns))))
		{
			System.out.println("mprn returned is invalid");
			status = false;
		}
		if (!(quoteReason.equals(Exp_quoteReason))) 
		{
			System.out.println("Quote reason returned is invalid");
			status = false;
		}
		if (!(quoteReference == Exp_quoteReference)) 
		{
			System.out.println("Quote reference returned is invalid");
			status = false;
		}
		if (!(tariffName.equals(Exp_tariffName))) 
		{
			System.out.println("Tariff name returned is invalid");
			status = false;
		}
		if (!(savingAmountGBP == Exp_savingAmountGBP)) 
		{
			System.out.println("SavingAmountGBP returned is invalid");
			status = false;
		}
		if (!(carbonSavingskg == Exp_carbonSavingskg)) 
		{
			System.out.println("CarbonSavingsKg returned is invalid");
			status = false;
		}
		if (!(annualQuoteAmountGBP == Exp_annualQuoteAmountGBP)) 
		{
			System.out.println("annualQuoteAmountGBP returned is invalid");
			status = false;
		}
		if (!(minAnnualQuoteAmountGBP == Exp_minAnnualQuoteAmountGBP)) 
		{
			System.out.println("minAnnualQuoteAmountGBP returned is invalid");
			status = false;
		}
		if (!(comparisonSupplier == null && Exp_comparisionSupplier.equals("null")||comparisonSupplier.equals(Exp_comparisionSupplier)))
		{
			System.out.println("comparisonSupplier returned is invalid");
			status = false;
		}
		if (!(elecAnnualUsagekWhs == Exp_elecAnnualUsagekWhs)) 
		{
			System.out.println("elecAnnualUsagekWhs returned is invalid");
			status = false;
		}
		if (!(elecUnitRate == Exp_elecUnitRate)) 
		{
			System.out.println("elecUnitRate returned is invalid");
			status = false;
		}
		if (!(elecAnnualAmounIncMFGBP == Exp_elecAnnualAmounIncMFGBP)) 
		{
			System.out.println("elecAnnualAmounIncMFGBP returned id invalid");
			status = false;
		}
		if (!(elecAnnualAmountExcMFGBP == Exp_elecAnnualAmountExcMFGBP)) 
		{
			System.out.println("elecAnnualAmountExcMFGBP returned is invalid");
			status = false;
		}
		if (!(elecMonthlyMembershipFeeGBP == Exp_elecMonthlyMembershipFeeGBP)) 
		{
			System.out.println("elecMonthlyMembershipFeeGBP returned is invalid");
			status = false;
		}
		if (!(elecAnnualMembershipFeeGBP == Exp_elecAnnualMembershipFeeGBP)) 
		{
			System.out.println("elecAnnualMembershipFeeGBP returned is invalid");
			status = false;
		}
		
		if (!(expiryDateTime == null && Exp_expiryDateTime.equals("null")||(expiryDateTime.equals("Exp_expiryDateTime"))))
		{
			System.out.println("expiryDateTime returned is invalid");
			status = false;
		}
		if (status) 
		{
			System.out.println("All the response parameters are verified");
		}
		else
		{
			System.out.println("Response returned is not as expected");
		}

	}
}
