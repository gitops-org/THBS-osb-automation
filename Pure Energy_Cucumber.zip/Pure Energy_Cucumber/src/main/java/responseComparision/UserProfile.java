package responseComparision;

import java.util.List;

import io.restassured.response.ResponseBody;
import me.doubledutch.lazyjson.LazyElement;

import org.json.simple.JSONObject;

import com.github.kvnxiao.jsonequals.JsonCompareResult;
import com.github.kvnxiao.jsonequals.JsonRoot;

import cucumberTest.GenericMethods;

public class UserProfile extends GenericMethods
{
	JsonRoot exp;
	JsonRoot act;
	//set expected response
	@SuppressWarnings("unchecked")
	public void setExpectedResponse(String path, String sheetName, int row)
	{
		Exp_memberId = getIntValues(path, sheetName, row, 0);
		Exp_title = getStringValues(path, sheetName, row, 1);
		Exp_firstName = getStringValues(path, sheetName, row, 2);
		Exp_lastName = getStringValues(path,sheetName, row, 3);
		Exp_dob = getStringValues(path, sheetName, row, 4);
		Exp_email = getStringValues(path, sheetName, row, 5);
		Exp_mob = getStringValues(path, sheetName, row, 6);
		Exp_EV = getBooleanValues(path, sheetName, row, 7);
		Exp_MV = getBooleanValues(path, sheetName, row, 8);
		Exp_role = getIntValues(path, sheetName, row, 9);
		Exp_AQ = getBooleanValues(path, sheetName, row, 10);

		//print expected values
		System.out.println("Expected Response parameters are: ");
		System.out.println("memberId: "+Exp_memberId);
		System.out.println("title: "+Exp_title);
		System.out.println("firstName: "+Exp_firstName);
		System.out.println("lastName: "+Exp_lastName);
		System.out.println("dateOfBirth: "+Exp_dob);
		System.out.println("email: "+Exp_email);
		System.out.println("mobileNo: "+Exp_mob);
		System.out.println("emailVerified: "+Exp_EV);
		System.out.println("mobileVerified: "+Exp_MV);
		System.out.println("role: "+Exp_role);
		System.out.println("activeQuote: "+Exp_AQ);
		System.out.println();
		
		JSONObject up = new JSONObject();
		up.put("memberId", Exp_memberId);
		up.put("title", Exp_title);
		up.put("firstName", Exp_firstName);
		up.put("lastName", Exp_lastName);
		up.put("dateOfBirth", Exp_dob);
		up.put("email", Exp_email);
		up.put("mobileNo", Exp_mob);
		up.put("emailVerified", Exp_EV);
		up.put("mobileVerified", Exp_MV);
		up.put("role", Exp_role);
		up.put("activeQuote", Exp_AQ);
		
		exp = JsonRoot.from(up.toJSONString());

	}
	
	//compare the expected response
		@SuppressWarnings("unchecked")
		public void compareResponse(int memberId,String title,String firstName, String lastName, String dob,String email, String mobileNo,boolean emailVerified, boolean mobileVerified, int role, boolean activeQuote)
		{
			boolean status = true;
			if (memberId != Exp_memberId) 
			{
				System.out.println("comparing "+memberId+" with "+Exp_memberId);
				System.out.println("Member id returned in the response is invalid");
				status = false;
			}
			if (!(title == null && Exp_title.equals("null")||(title.equals(Exp_title)))) 
			{
				System.out.println("comparing "+title+" with "+Exp_title);
				System.out.println("Title returned is invalid");
				status = false;
			}
			if (!(firstName.equals(Exp_firstName))) 
			{
				System.out.println("comparing "+firstName+" with "+Exp_firstName);
				System.out.println("first Name returned is invalid");
				status = false;
			}
			if (!(lastName.equals(Exp_lastName))) 
			{
				System.out.println("comparing "+lastName+" with "+Exp_lastName);
				System.out.println("last name returned is invalid");
				status = false;
			}
			if (!(dob == null && Exp_dob.equals("null")||(dob.equals(Exp_dob)))) 
			{
				System.out.println("comparing "+dob+" with "+Exp_dob);
				System.out.println("date of birth returned is invalid");
				status = false;
			}
			if (!(mobileNo == null && Exp_mob.equals("null")||(mobileNo.equals(Exp_mob)))) 
			{
				System.out.println("comparing "+mobileNo+" with "+Exp_mob);
				System.out.println("mobile number returned is invalid");
				status = false;
			}
			if (!(emailVerified == Exp_EV)) 
			{
				System.out.println("comparing "+emailVerified+" with "+Exp_EV);
				System.out.println("email verified returned is invalid");
				status = false;
			}
			if (!(mobileVerified == Exp_MV)) 
			{
				System.out.println("comparing "+mobileVerified+" with "+Exp_MV);
				System.out.println("mobile verified returned is invalid");
				status = false;
			}
			if (!(role == Exp_role)) 
			{
				System.out.println("comparing "+role+" with "+Exp_role);
				System.out.println("expected role returned is invalid");
				status = false;
			}
			if (!(activeQuote == Exp_AQ)) 
			{
				System.out.println("comparing "+activeQuote+" with "+Exp_AQ);
				System.out.println("active quote returned is invalid");
				status = false;
			}
			if (status) 
			{
				System.out.println("All the response elements are verified");
				System.out.println();
			} else {
				System.out.println("Response is not as expected");
				System.out.println();
			}
		
		/*	
			JSONObject up = new JSONObject();
			up.put("memberId", memberId);
			up.put("title", title);
			up.put("firstName", firstName);
			up.put("lastName", lastName);
			up.put("dateOfBirth", dob);
			up.put("email", email);
			up.put("mobileNo", mobileNo);
			up.put("emailVerified", emailVerified);
			up.put("mobileVerified", mobileVerified);
			up.put("role", role);
			up.put("activeQuote", activeQuote);
			
			act = JsonRoot.from(up.toJSONString());
			
			JsonCompareResult result = exp.compareTo(act);
			
			List<String> msgs = result.getSuccessMessages();
			List<String> msgs1 = result.getInequalityMessages();
			
			boolean equal = result.isEqual();
			
			if (equal) 
			{
				System.out.println("All the response parameters are verified");
			} else {
				System.out.println("Response parametes returned is not expected");
				System.out.println(msgs1);
				
			}*/

		}
		
}
