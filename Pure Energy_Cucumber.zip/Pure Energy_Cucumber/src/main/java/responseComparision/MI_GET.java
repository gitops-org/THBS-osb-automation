package responseComparision;

import cucumberTest.GenericMethods;

public class MI_GET extends GenericMethods
{
	public void setExpectedResponse(String path, String sheetName, int row)
	{
		Exp_memberId = getIntValues(path, sheetName, row, 0);
		Exp_title = getStringValues(path, sheetName, row, 1);
		Exp_firstName = getStringValues(path, sheetName, row, 2);
		Exp_lastName = getStringValues(path,sheetName, row, 3);
		Exp_dob = getStringValues(path, sheetName, row, 4);
		Exp_email = getStringValues(path, sheetName, row, 5);
		Exp_mob = getStringValues(path, sheetName, row, 6);
		Exp_EV = getBooleanValues(path, sheetName, row, 7);
		Exp_MV = getBooleanValues(path, sheetName, row, 8);

		//print expected values
		System.out.println("Expected Response parameters are: ");
		System.out.println("memberId: "+Exp_memberId);
		System.out.println("title: "+Exp_title);
		System.out.println("firstName: "+Exp_firstName);
		System.out.println("lastName: "+Exp_lastName);
		System.out.println("dateOfBirth: "+Exp_dob);
		System.out.println("email: "+Exp_email);
		System.out.println("mobileNo: "+Exp_mob);
		System.out.println("emailVerified: "+Exp_EV);
		System.out.println("mobileVerified: "+Exp_MV);
	}
	
	//compare response MI GET

		public void compareResponse(int memberId,String title,String firstName, String lastName, String dob,String email, String mobileNo,boolean emailVerified, boolean mobileVerified)
		{
			boolean status = true;
			if (memberId != Exp_memberId) 
			{
				System.out.println("Member Id returned is invalid");
				System.out.println(Exp_memberId);
				status = false;
			}
			if (!((title == null&&Exp_title.equals("null"))||(title.equals(Exp_title)))) 
			{
				System.out.println("title returned is invalid");
				status = false;
			}
			if (!(firstName == null || firstName.equals(Exp_firstName))) 
			{
				System.out.println("first name returned is invalid");
				status = false;
			}
			if (!(lastName == null || lastName.equals(Exp_lastName))) 
			{
				System.out.println("last name returned is invalid");
				status = false;
			}
			if (!(dob == null || dob.equals(Exp_dob))) 
			{
				System.out.println("Date of Birth returned is invalid");
				status = false;
			}
			if (!(email == null || email.equals(Exp_email))) 
			{
				System.out.println("email returned is invalid");
				status = false;
			}
			if (!(mobileNo == null || mobileNo.equals(Exp_mob))) 
			{
				System.out.println("Mobile number returned is invalid");
				status = false;
			}
			if (!(emailVerified == Exp_EV)) 
			{
				System.out.println("Email verified returned is invalid");
				status = false;
			}
			if (!(mobileVerified == Exp_MV)) 
			{
				System.out.println("mobile verified returned is invalid");
				status = false;
			}

			if (status) {
				System.out.println("All the response elements are verified");
			} else {
				System.out.println("Response is not as expected");
			}


		}
}
