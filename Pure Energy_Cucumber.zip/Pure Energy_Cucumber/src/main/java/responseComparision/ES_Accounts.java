package responseComparision;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import cucumberTest.GenericMethods;

public class ES_Accounts extends GenericMethods
{
	String Exp_memberId, Exp_accountNumber, Exp_sortcode, Exp_nextPaymentDt, Exp_dateAllowed, Exp_reasonNotAllowed, Exp_address1, Exp_address2, Exp_address3, Exp_city, Exp_state, Exp_postcode, Exp_country;
	String Exp_tariffElec, Exp_productTypeElec, Exp_tariffGas, Exp_productTypeGas, Exp_discountCode, Exp_discountType;
	int Exp_regularPaymentDayOfMonth, Exp_summerMonthDDAmtGbp, Exp_winterMonthDDAmtGbp, Exp_monthlyMembershipFeeElec, Exp_annualMembershipFeeElec, Exp_monthlyMembershipFeeGas, Exp_annualMembershipFeeGas, Exp_discountAmount;
	double Exp_unitRateElec, Exp_unitRateGas;
	boolean Exp_cancelSwitchAllowed, Exp_updateAllowed, Exp_discountApplied;
	/*  
	 * skip all the response parameters which is based on junifer response
	 * check if u can validate whether the particular response element is returned or not
	 * check null pointer exception in GET PSR response validation
	 */

	@SuppressWarnings("unchecked")
	public void setExpectedResponse(String path, String sheetName, int row)
	{
		Exp_memberId = getStringValues(path, sheetName, row, 0);
		Exp_title = getStringValues(path, sheetName, row, 1);
		Exp_firstName = getStringValues(path, sheetName, row, 2);
		Exp_lastName = getStringValues(path, sheetName, row, 3);
		Exp_mob = getStringValues(path, sheetName, row, 4);
		Exp_email = getStringValues(path, sheetName, row, 5);
		Exp_cancelSwitchAllowed = getBooleanValues(path, sheetName, row, 6);
		Exp_accountNumber = getStringValues(path, sheetName, row, 7);
		Exp_sortcode = getStringValues(path, sheetName, row, 8);
		Exp_regularPaymentDayOfMonth = getIntValues(path, sheetName, row, 9);
		Exp_nextPaymentDt = getStringValues(path, sheetName, row, 10);
		Exp_summerMonthDDAmtGbp = getIntValues(path, sheetName, row, 11);
		Exp_winterMonthDDAmtGbp = getIntValues(path, sheetName, row, 12);
		Exp_updateAllowed = getBooleanValues(path, sheetName, row, 13);
		Exp_dateAllowed = getStringValues(path, sheetName, row, 14);
		Exp_reasonNotAllowed = getStringValues(path, sheetName, row, 15);
		Exp_address1 = getStringValues(path, sheetName, row, 16);
		Exp_address2 = getStringValues(path, sheetName, row, 17);
		Exp_address3 = getStringValues(path, sheetName, row, 18);
		Exp_city = getStringValues(path, sheetName, row, 19);
		Exp_state = getStringValues(path, sheetName, row, 20);
		Exp_postcode = getStringValues(path, sheetName, row, 21);
		Exp_country = getStringValues(path, sheetName, row, 22);
		Exp_tariffElec = getStringValues(path, sheetName, row, 23);
		Exp_productTypeElec = getStringValues(path, sheetName, row, 24);
		Exp_monthlyMembershipFeeElec = getIntValues(path, sheetName, row, 25);
		Exp_annualMembershipFeeElec = getIntValues(path, sheetName, row, 26);
		Exp_unitRateElec = getDoubleValues(path, sheetName, row, 27);
		Exp_tariffGas = getStringValues(path, sheetName, row, 28);
		Exp_productTypeGas = getStringValues(path, sheetName, row, 29);
		Exp_monthlyMembershipFeeGas = getIntValues(path, sheetName, row, 30);
		Exp_annualMembershipFeeGas = getIntValues(path, sheetName, row, 31);
		Exp_unitRateGas = getDoubleValues(path, sheetName, row, 32);
		Exp_discountCode = getStringValues(path, sheetName, row, 33);
		Exp_discountType = getStringValues(path, sheetName, row, 34);
		Exp_discountAmount = getIntValues(path, sheetName, row, 35);
		Exp_discountApplied = getBooleanValues(path, sheetName, row, 36);

		JSONObject ddMan = new JSONObject();
		ddMan.put("accountNumber", Exp_accountNumber);
		ddMan.put("sortcode", Exp_sortcode);
		ddMan.put("regularPaymentDayOfMonth", Exp_regularPaymentDayOfMonth);
		ddMan.put("nextPaymentDt", Exp_nextPaymentDt);
		ddMan.put("summerMonthDDAmtGbp", Exp_summerMonthDDAmtGbp);
		ddMan.put("winterMonthDDAmtGbp", Exp_winterMonthDDAmtGbp);
		ddMan.put("updateAllowed", Exp_updateAllowed);
		ddMan.put("dateAllowed", Exp_dateAllowed);
		ddMan.put("reasonNotAllowed", Exp_reasonNotAllowed);

		JSONObject address = new JSONObject();
		address.put("address1", Exp_address1);
		address.put("address2", Exp_address2);
		address.put("address3", Exp_address3);
		address.put("city", Exp_city);
		address.put("state", Exp_state);
		address.put("postcode", Exp_postcode);
		address.put("country", Exp_country);

		JSONArray prod = new JSONArray();
		JSONObject pr1 = new JSONObject();
		pr1.put("tariff", Exp_tariffElec);
		pr1.put("productType", Exp_productTypeElec);
		pr1.put("monthlyMembershipFee", Exp_monthlyMembershipFeeElec);
		pr1.put("annualMembershipFee", Exp_annualMembershipFeeElec);

		if (Exp_tariffGas.equals("null")) 
		{
			prod.add(pr1);
		}
		else
		{
			JSONObject pr2 = new JSONObject();
			pr2.put("tariff", Exp_tariffGas);
			pr2.put("productType", Exp_productTypeGas);
			pr2.put("monthlyMembershipFee", Exp_monthlyMembershipFeeGas);
			pr2.put("annualMembershipFee", Exp_annualMembershipFeeGas);

			prod.add(pr1);
			prod.add(pr2);
		}

		JSONObject discounts = new JSONObject();
		discounts.put("discountCode", Exp_discountCode);
		discounts.put("discountType", Exp_discountType);
		discounts.put("discountAmount", Exp_discountAmount);
		discounts.put("discountApplied", Exp_discountApplied);
		
		if (Exp_discountCode.equals("null")) 
		{
			JSONObject es = new JSONObject();
			es.put("memberId", Exp_memberId);
			es.put("title", Exp_title);
			es.put("firstName", Exp_firstName);
			es.put("lastName", Exp_lastName);
			es.put("mobile", Exp_mob);
			es.put("email", Exp_email);
			es.put("cancelSwitchAllowed", Exp_cancelSwitchAllowed);
			es.put("ddMandateDetails", ddMan);
			es.put("address", address);
			es.put("productDetails", prod);
			
		} else 
		{
			JSONObject es = new JSONObject();
			es.put("memberId", Exp_memberId);
			es.put("title", Exp_title);
			es.put("firstName", Exp_firstName);
			es.put("lastName", Exp_lastName);
			es.put("mobile", Exp_mob);
			es.put("email", Exp_email);
			es.put("cancelSwitchAllowed", Exp_cancelSwitchAllowed);
			es.put("ddMandateDetails", ddMan);
			es.put("address", address);
			es.put("productDetails", prod);
			es.put("discounts", discounts);
		}

	}

	public void compareExpectedResponseElec(String memberId, String title, String firstName, String lastName, String mobile, String email, boolean cancelSwitchAllowed, String accountNumber, String sortcode, int regularPaymentDayOfMonth, String nextPaymentDt, int summerMonthDDAmtGbp, int winterMonthDDAmtGbp, boolean updateAllowed, String dateAllowed, String reasonNotAllowed, String address1, String address2, String address3, String city, String state, String postcode, String country, String tariff, String productType, int monthlyMembershipFee, int annualMembershipFee, double unitRate)
	{
		boolean status = true;

		if (!(memberId.equals(Exp_memberId))) 
		{
			System.out.println("Member Id returned is invalid");
			status = false;
		}
		if (!(title.equals(Exp_title))) 
		{
			System.out.println("title returned is invalid");
			status = false;
		}
		if (!(firstName.equals(Exp_firstName))) 
		{
			System.out.println("firstName returned is invalid");
			status = false;
		}
		if (!(lastName.equals(Exp_lastName))) 
		{
			System.out.println("lastName returned is invalid");
			status = false;
		}
		if (!(mobile.equals(Exp_mob))) 
		{
			System.out.println("mobile returned is invalid");
			status = false;
		}
		if (!(email.equals(Exp_email))) 
		{
			System.out.println("Email returned is invalid");
			status = false;
		}
		if (!(cancelSwitchAllowed == Exp_cancelSwitchAllowed)) 
		{
			System.out.println("cancelSwitchAllowed returned is invalid");
			status = false;
		}
		if (!(accountNumber.equals(Exp_accountNumber))) 
		{
			System.out.println("accountNumber returned is invalid");
			status = false;
		}
		if (!(sortcode.equals(Exp_sortcode))) 
		{
			System.out.println("sortcode returned is invalid");
			status = false;
		}
		if (!(regularPaymentDayOfMonth == Exp_regularPaymentDayOfMonth)) 
		{
			System.out.println("regularPaymentDayOfMonth returned is invalid");
			status = false;
		}
		if (!(nextPaymentDt.equals(Exp_nextPaymentDt))) 
		{
			System.out.println("nextPaymentDt returned is invalid");
			status = false;
		}
		if (!(summerMonthDDAmtGbp == Exp_summerMonthDDAmtGbp)) 
		{
			System.out.println("summerMonthDDAmtGbp returned is invalid");
			status = false;
		}
		if (!(winterMonthDDAmtGbp == Exp_winterMonthDDAmtGbp)) 
		{
			System.out.println("winterMonthDDAmtGbp returned is invalid");
			status = false;
		}
		if (!(updateAllowed == Exp_updateAllowed)) 
		{
			System.out.println("updateAllowed returned is invalid");
			status = false;
		}
		if (!(dateAllowed.equals(Exp_dateAllowed))) 
		{
			System.out.println("dateAllowed returned is invalid");
			status = false;
		}
		if (!(reasonNotAllowed.equals(Exp_reasonNotAllowed))) 
		{
			System.out.println("reasonNotAllowed returned is invalid");
			status = false;
		}
		if (!(address1.equals(Exp_address1))) 
		{
			System.out.println("address1 returned is invalid");
			status = false;
		}
		if (!(address2.equals(Exp_address2))) 
		{
			System.out.println("address2 returned is invalid");
			status = false;
		}
		if (!(address3.equals(Exp_address3))) 
		{
			System.out.println("address3 returned is invalid");
			status = false;
		}
		if (!(city.equals(Exp_city))) 
		{
			System.out.println("city returned is invalid");
			status = false;
		}
		if (!(state.equals(Exp_state))) 
		{
			System.out.println("state returned is invalid");
			status = false;
		}
		if (!(postcode.equals(Exp_postcode))) 
		{
			System.out.println("postcode returned is invalid");
			status = false;
		}
		if (!(country.equals(Exp_country))) 
		{
			System.out.println("country returned is invalid");
			status = false;
		}
		if (!(tariff.equals(Exp_tariffElec))) 
		{
			System.out.println("tariff returned is invalid");
			status = false;
		}
		if (!(productType.equals(Exp_productTypeElec))) 
		{
			System.out.println("productType returned is invalid");
			status = false;
		}
		if (!(monthlyMembershipFee == Exp_monthlyMembershipFeeElec)) 
		{
			System.out.println("monthlyMembershipFee returned is invalid");
			status = false;
		}
		if (!(annualMembershipFee == Exp_annualMembershipFeeElec)) 
		{
			System.out.println("annualMembershipFee returned is invalid");
			status = false;
		}
		if (!(unitRate == Exp_unitRateElec)) 
		{
			System.out.println("unitRate returned is invalid");
			status = false;
		}
		if (status) 
		{
			System.out.println("All response parameters returned are verified");
		} else {
			System.out.println("Response returned is not as expected");
		}


	}

	public void compareExpectedResponseElec(String memberId, String title, String firstName, String lastName, String mobile, String email, boolean cancelSwitchAllowed, String accountNumber, String sortcode, int regularPaymentDayOfMonth, String nextPaymentDt, int summerMonthDDAmtGbp, int winterMonthDDAmtGbp, boolean updateAllowed, String address1, String address2, String address3, String city, String state, String postcode, String country, String tariff, String productType, int monthlyMembershipFee, int annualMembershipFee, double unitRate)
	{
		boolean status = true;

		if (!(memberId.equals(Exp_memberId))) 
		{
			System.out.println("Member Id returned is invalid");
			status = false;
		}
		if (!(title.equals(Exp_title))) 
		{
			System.out.println("title returned is invalid");
			status = false;
		}
		if (!(firstName.equals(Exp_firstName))) 
		{
			System.out.println("firstName returned is invalid");
			status = false;
		}
		if (!(lastName.equals(Exp_lastName))) 
		{
			System.out.println("lastName returned is invalid");
			status = false;
		}
		if (!(mobile.equals(Exp_mob))) 
		{
			System.out.println("mobile returned is invalid");
			status = false;
		}
		if (!(email.equals(Exp_email))) 
		{
			System.out.println("Email returned is invalid");
			status = false;
		}
		if (!(cancelSwitchAllowed == Exp_cancelSwitchAllowed)) 
		{
			System.out.println("cancelSwitchAllowed returned is invalid");
			status = false;
		}
		if (!(accountNumber.equals(Exp_accountNumber))) 
		{
			System.out.println("accountNumber returned is invalid");
			status = false;
		}
		if (!(sortcode.equals(Exp_sortcode))) 
		{
			System.out.println("sortcode returned is invalid");
			status = false;
		}
		if (!(regularPaymentDayOfMonth == Exp_regularPaymentDayOfMonth)) 
		{
			System.out.println("regularPaymentDayOfMonth returned is invalid");
			status = false;
		}
		if (!(nextPaymentDt.equals(Exp_nextPaymentDt))) 
		{
			System.out.println("nextPaymentDt returned is invalid");
			status = false;
		}
		if (!(summerMonthDDAmtGbp == Exp_summerMonthDDAmtGbp)) 
		{
			System.out.println("summerMonthDDAmtGbp returned is invalid");
			status = false;
		}
		if (!(winterMonthDDAmtGbp == Exp_winterMonthDDAmtGbp)) 
		{
			System.out.println("winterMonthDDAmtGbp returned is invalid");
			status = false;
		}
		if (!(updateAllowed == Exp_updateAllowed)) 
		{
			System.out.println("updateAllowed returned is invalid");
			status = false;
		}
		if (!(address1.equals(Exp_address1))) 
		{
			System.out.println("address1 returned is invalid");
			status = false;
		}
		if (!(address2.equals(Exp_address2))) 
		{
			System.out.println("address2 returned is invalid");
			status = false;
		}
		if (!(address3.equals(Exp_address3))) 
		{
			System.out.println("address3 returned is invalid");
			status = false;
		}
		if (!(city.equals(Exp_city))) 
		{
			System.out.println("city returned is invalid");
			status = false;
		}
		if (!(state.equals(Exp_state))) 
		{
			System.out.println("state returned is invalid");
			status = false;
		}
		if (!(postcode.equals(Exp_postcode))) 
		{
			System.out.println("postcode returned is invalid");
			status = false;
		}
		if (!(country.equals(Exp_country))) 
		{
			System.out.println("country returned is invalid");
			status = false;
		}
		if (!(tariff.equals(Exp_tariffElec))) 
		{
			System.out.println("tariff returned is invalid");
			status = false;
		}
		if (!(productType.equals(Exp_productTypeElec))) 
		{
			System.out.println("productType returned is invalid");
			status = false;
		}
		if (!(monthlyMembershipFee == Exp_monthlyMembershipFeeElec)) 
		{
			System.out.println("monthlyMembershipFee returned is invalid");
			status = false;
		}
		if (!(annualMembershipFee == Exp_annualMembershipFeeElec)) 
		{
			System.out.println("annualMembershipFee returned is invalid");
			status = false;
		}
		if (!(unitRate == Exp_unitRateElec)) 
		{
			System.out.println("unitRate returned is invalid");
			status = false;
		}
		if (status) 
		{
			System.out.println("All response parameters returned are verified");
		} else {
			System.out.println("Response returned is not as expected");
		}
	}

	public void compareExpectedResponseDual(String memberId, String title, String firstName, String lastName, String mobile, String email, boolean cancelSwitchAllowed, String accountNumber, String sortcode, int regularPaymentDayOfMonth, String nextPaymentDt, int summerMonthDDAmtGbp, int winterMonthDDAmtGbp, boolean updateAllowed, String dateAllowed, String reasonNotAllowed, String address1, String address2, String address3, String city, String state, String postcode, String country, String tariffElec, String productTypeElec, int monthlyMembershipFeeElec, int annualMembershipFeeElec, String[] unitRateElec, String tariffGas, String productTypeGas, int monthlyMembershipFeeGas, int annualMembershipFeeGas, double unitRateGas, String discountCode, String discountType, int discountAmount, boolean discountApplied )
	{		
		boolean status = true;

		if (!(memberId.equals(Exp_memberId))) 
		{
			System.out.println("Member Id returned is invalid");
			status = false;
		}
		if (!(title.equals(Exp_title))) 
		{
			System.out.println("title returned is invalid");
			status = false;
		}
		if (!(firstName.equals(Exp_firstName))) 
		{
			System.out.println("firstName returned is invalid");
			status = false;
		}
		if (!(lastName.equals(Exp_lastName))) 
		{
			System.out.println("lastName returned is invalid");
			status = false;
		}
		if (!(mobile.equals(Exp_mob))) 
		{
			System.out.println("mobile returned is invalid");
			status = false;
		}
		if (!(email.equals(Exp_email))) 
		{
			System.out.println("Email returned is invalid");
			status = false;
		}
		if (!(cancelSwitchAllowed == Exp_cancelSwitchAllowed)) 
		{
			System.out.println("cancelSwitchAllowed returned is invalid");
			status = false;
		}
		if (!(accountNumber.equals(Exp_accountNumber))) 
		{
			System.out.println("accountNumber returned is invalid");
			status = false;
		}
		if (!(sortcode.equals(Exp_sortcode))) 
		{
			System.out.println("sortcode returned is invalid");
			status = false;
		}
		if (!(regularPaymentDayOfMonth == Exp_regularPaymentDayOfMonth)) 
		{
			System.out.println("regularPaymentDayOfMonth returned is invalid");
			status = false;
		}
		if (!(nextPaymentDt.equals(Exp_nextPaymentDt))) 
		{
			System.out.println("nextPaymentDt returned is invalid");
			status = false;
		}
		if (!(summerMonthDDAmtGbp == Exp_summerMonthDDAmtGbp)) 
		{
			System.out.println("summerMonthDDAmtGbp returned is invalid");
			status = false;
		}
		if (!(winterMonthDDAmtGbp == Exp_winterMonthDDAmtGbp)) 
		{
			System.out.println("winterMonthDDAmtGbp returned is invalid");
			status = false;
		}
		if (!(updateAllowed == Exp_updateAllowed)) 
		{
			System.out.println("updateAllowed returned is invalid");
			status = false;
		}
		if (!(dateAllowed.equals(Exp_dateAllowed))) 
		{
			System.out.println("dateAllowed returned is invalid");
			status = false;
		}
		if (!(reasonNotAllowed.equals(Exp_reasonNotAllowed))) 
		{
			System.out.println("reasonNotAllowed returned is invalid");
			status = false;
		}
		if (!(address1.equals(Exp_address1))) 
		{
			System.out.println("address1 returned is invalid");
			status = false;
		}
		if (!(address2.equals(Exp_address2))) 
		{
			System.out.println("address2 returned is invalid");
			status = false;
		}
		if (!(address3.equals(Exp_address3))) 
		{
			System.out.println("address3 returned is invalid");
			status = false;
		}
		if (!(city.equals(Exp_city))) 
		{
			System.out.println("city returned is invalid");
			status = false;
		}
		if (!(state.equals(Exp_state))) 
		{
			System.out.println("state returned is invalid");
			status = false;
		}
		if (!(postcode.equals(Exp_postcode))) 
		{
			System.out.println("postcode returned is invalid");
			status = false;
		}
		if (!(country.equals(Exp_country))) 
		{
			System.out.println("country returned is invalid");
			status = false;
		}
		if (!(tariffElec.equals(Exp_tariffElec))) 
		{
			System.out.println("tariff returned is invalid");
			status = false;
		}
		if (!(productTypeElec.equals(Exp_productTypeElec))) 
		{
			System.out.println("productType returned is invalid");
			status = false;
		}
		if (!(monthlyMembershipFeeElec == Exp_monthlyMembershipFeeElec)) 
		{
			System.out.println("monthlyMembershipFee returned is invalid");
			status = false;
		}
		if (!(annualMembershipFeeElec == Exp_annualMembershipFeeElec)) 
		{
			System.out.println("annualMembershipFee returned is invalid");
			status = false;
		}

		for (int i = 0; i < unitRateElec.length-1; i++) 
		{
			String a = unitRateElec[i];
			double b = Double.parseDouble(a);
			if (!(b == Exp_unitRateElec)) 
			{
				System.out.println("unitRate returned is invalid");
				status = false;
			}
		}
		if (!(tariffGas.equals(Exp_tariffGas))) 
		{
			System.out.println("tariffGas returned is invalid");
			status = false;
		}
		if (!(productTypeGas.equals(Exp_productTypeGas))) 
		{
			System.out.println("productTypeGas returned is invalid");
			status = false;
		}
		if (!(monthlyMembershipFeeGas == Exp_monthlyMembershipFeeGas)) 
		{
			System.out.println("monthlyMembershipFeeGas returned is invalid");
			status = false;
		}
		if (!(annualMembershipFeeGas == Exp_annualMembershipFeeGas)) 
		{
			System.out.println("annualMembershipFeeGas returned is invalid");
			status = false;
		}
		if (!(unitRateGas == Exp_unitRateGas)) 
		{
			System.out.println("unitRateGas returned is invalid");
			status = false;
		}
		if (!(discountCode.equals(Exp_discountCode))) 
		{
			System.out.println("discountCode returned is invalid");
			status = false;
		}
		if (!(discountType.equals(Exp_discountType))) 
		{
			System.out.println("discountType returned is invalid");
			status = false;
		}
		if (!(discountAmount == Exp_discountAmount)) 
		{
			System.out.println("discountAmount returned is invalid");
			status = false;
		}
		if (!(discountApplied == Exp_discountApplied)) 
		{
			System.out.println("discountApplied returned is invalid");
			status = false;
		}
		if (status) 
		{
			System.out.println("All response parameters returned are verified");
		} else {
			System.out.println("Response returned is not as expected");
		}

	}

	public void compareExpectedResponseDualJE(String memberId, String title, String firstName, String lastName, String mobile, String email, boolean cancelSwitchAllowed, String accountNumber, String sortcode, int regularPaymentDayOfMonth, String nextPaymentDt, int summerMonthDDAmtGbp, int winterMonthDDAmtGbp, boolean updateAllowed, String dateAllowed, String reasonNotAllowed, String address1, String address2, String address3, String city, String state, String postcode, String country, String tariffElec, String productTypeElec, int monthlyMembershipFeeElec, int annualMembershipFeeElec, String[] unitRateElec, String tariffGas, String productTypeGas, int monthlyMembershipFeeGas, int annualMembershipFeeGas, double unitRateGas, String discountCode, String discountType, int discountAmount, boolean discountApplied )
	{		
		boolean status = true;


	}
}
