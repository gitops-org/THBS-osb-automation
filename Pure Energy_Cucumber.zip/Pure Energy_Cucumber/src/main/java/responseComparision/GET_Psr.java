package responseComparision;

import cucumberTest.GenericMethods;

public class GET_Psr extends GenericMethods
{
	String[] Exp_homeAssistancePSRsArray;
	String[] Exp_personalAssistanceNeedsPSRsArray;
	String[] Exp_personalAssistanceCommunicationPSRsArray;
	String homeAssistancePSRs, personalAssistanceNeedsPSRs, personalAssistanceCommunicationPSRs, Exp_otherConsideration, Exp_authorisedContactName, Exp_authorisedContactEmail, Exp_password;
	boolean Exp_sendEmailToAuthorisedContact, Exp_sendForMeterRead;

	public void setExpectedResponse(String path, String sheetName, int row)
	{
		Exp_memberId = getIntValues(path, sheetName, row, 0);
		homeAssistancePSRs = getStringValues(path, sheetName, row, 1);
		personalAssistanceNeedsPSRs = getStringValues(path, sheetName, row, 2);
		personalAssistanceCommunicationPSRs = getStringValues(path, sheetName, row, 3);
		Exp_otherConsideration = getStringValues(path, sheetName, row, 4);
		Exp_authorisedContactName = getStringValues(path, sheetName, row, 5);
		Exp_authorisedContactEmail = getStringValues(path, sheetName, row, 6);
		Exp_sendEmailToAuthorisedContact = getBooleanValues(path, sheetName, row, 7);
		Exp_password = getStringValues(path, sheetName, row, 8);
		Exp_sendForMeterRead = getBooleanValues(path, sheetName, row, 9);
		Exp_homeAssistancePSRsArray = homeAssistancePSRs.split(",");
		Exp_personalAssistanceNeedsPSRsArray = personalAssistanceNeedsPSRs.split(",");
		Exp_personalAssistanceCommunicationPSRsArray = personalAssistanceCommunicationPSRs.split(",");

		//print expected response elements
		System.out.println("Expected Response Parameters are: ");
		System.out.println("memberId: "+Exp_memberId);
		System.out.println("homeAssistancePSRs: "+homeAssistancePSRs);
		System.out.println("personalAssistanceNeedsPSRs: "+personalAssistanceNeedsPSRs);
		System.out.println("personalAssistanceCommunicationPSRs: "+personalAssistanceCommunicationPSRs);
		System.out.println("otherConsideration: "+Exp_otherConsideration);
		System.out.println("authorisedContactName: "+Exp_authorisedContactName);
		System.out.println("authorisedContactEmail: "+Exp_authorisedContactEmail);
		System.out.println("sendEmailToAuthorisedContact: "+Exp_sendEmailToAuthorisedContact);
		System.out.println("password: "+Exp_password);
		System.out.println("sendForMeterRead: "+Exp_sendForMeterRead);

	}

	public void compareResponse(int memberId, String[] homeAssistancePSRs, String[] personalAssistanceNeedsPSRs, String[] personalAssistanceCommunicationPSRs, String otherConsideration, String authorisedContactName, String authorisedContactEmail, boolean sendEmailToAuthorisedContact, String password, boolean sendForMeterRead)
	{
		boolean status = true;
		if (memberId != Exp_memberId) 
		{
			System.out.println("Member Id returned is invalid");
			System.out.println(Exp_memberId);
			status = false;
		}
		if (!((otherConsideration == null&&Exp_otherConsideration.equals("null"))||(otherConsideration.equals(Exp_otherConsideration)))) 
		{
			System.out.println("otherConsideration returned is invalid");
			status = false;
		}
		if (!((authorisedContactName == null&&Exp_authorisedContactName.equals("null"))||(authorisedContactName.equals(Exp_authorisedContactName)))) 
		{
			System.out.println("authorisedContactName returned is invalid");
			status = false;
		}
		/*if (!((authorisedContactEmail.equals(Exp_authorisedContactEmail))||(authorisedContactEmail == null&&Exp_authorisedContactEmail.equals("null")))) 
		{
			System.out.println("authorisedContactEmail returned is invalid");
			status = false;
		}*/
		if (!((password == null&&Exp_password.equals("null"))||(password.equals(Exp_password)))) 
		{
			System.out.println("password returned is invalid");
			status = false;
		}
		if (!(sendForMeterRead == Exp_sendForMeterRead)) 
		{
			System.out.println("sendForMeterRead returned is invalid");
			status = false;
		}
		if (!(sendEmailToAuthorisedContact == Exp_sendEmailToAuthorisedContact)) 
		{
			System.out.println("sendEmailToAuthorisedContact returned is invalid");
			status = false;
		}

		for (int i = 0; i < homeAssistancePSRs.length; i++) 
		{
			String tempa = homeAssistancePSRs[i];

			for (int j = 0; j < Exp_homeAssistancePSRsArray.length; j++) 
			{
				if (i == j) 
				{
					String tempb = Exp_homeAssistancePSRsArray[j];
					if (!(tempa.equals(tempb))) 
					{
						System.out.println("PSR: "+tempa+" returned is invalid");
						System.out.println("PSR: "+tempb+" should have been returned");
						status = false;
					}
				}
			}
		}

		for (int i = 0; i < personalAssistanceNeedsPSRs.length; i++) 
		{
			String tempa = personalAssistanceNeedsPSRs[i];
			for (int j = 0; j < Exp_personalAssistanceNeedsPSRsArray.length; j++) 
			{
				if (i == j)
				{
					String tempb = Exp_personalAssistanceNeedsPSRsArray[j];
					if (!(tempa.equals(tempb))) 
					{
						System.out.println("PSR: "+tempa+" returned is invalid");
						System.out.println("PSR: "+tempb+" should have been returned");
						status = false;
					}				
				}
			}
		}

		for (int i = 0; i < personalAssistanceCommunicationPSRs.length; i++) 
		{
			String tempa = personalAssistanceCommunicationPSRs[i];
			for (int j = 0; j < Exp_personalAssistanceCommunicationPSRsArray.length; j++) 
			{
				if (i == j) {
					String tempb = Exp_personalAssistanceCommunicationPSRsArray[j];
					if (!(tempa.equals(tempb)))
					{
						System.out.println("PSR: "+tempa+" returned is invalid");
						System.out.println("PSR: "+tempb+" should have been returned");
						status = false;
					}
				}
			}
		}

		if (status) {
			System.out.println("All the response elements are verified");
		} else {
			System.out.println("Response is not as expected");
		}
	}
}
