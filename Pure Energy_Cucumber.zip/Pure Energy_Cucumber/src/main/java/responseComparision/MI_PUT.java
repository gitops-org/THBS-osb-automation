package responseComparision;

import cucumberTest.GenericMethods;

public class MI_PUT extends GenericMethods 
{
	public void setExpectedResponse(int memberId,String title, String firstName, String lastName, String email, String mobile, String dateOfBirth)
	{
		Exp_memberId = memberId;
		Exp_title = title;
		Exp_firstName = firstName;
		Exp_lastName = lastName;
		Exp_email  = email;
		Exp_mob = mobile;
		Exp_dob = dateOfBirth;
	}
	
	public void compareResponse(int memberId, String title, String firstName, String lastName, String email, String mobileNo, String dateOfBirth)
	{
		boolean status = true;
		if (!(memberId == Exp_memberId))
		{
			System.out.println("MemberId returned is invalid");
			status = false;
		}
		if (!((title == null || title.equals(Exp_title))||(title == null && Exp_title == null)))
		{
			System.out.println("Title returned is invalid");
			status = false;
		}
		if (!(firstName == null || firstName.equals(Exp_firstName))) 
		{
			System.out.println("FirstName returned is invalid");
		}
		if (!(lastName == null || lastName.equals(Exp_lastName))) 
		{
			System.out.println("LastName returned is invalid");
			status = false;
		}
		if (!((dateOfBirth == null || title.equals(Exp_dob))||(dateOfBirth == null && Exp_dob == null)))
		{
			System.out.println("Date of Birth returned is invalid");
			status = false;
		}
		if (!(email == null || email.equals(Exp_email))) 
		{
			System.out.println("Email returned is invalid");
			status = false;
		}
		if (!((mobileNo == null || title.equals(Exp_mob))||(mobileNo == null && Exp_mob == null)))
		{
			System.out.println("Mobile number returned is invalid");
			status = false;
		}
		if(status)
		{
			System.out.println("All the response parameters are verified");
		}
		else
		{
			System.out.println("Response is not as expected");
		}

	}
}
