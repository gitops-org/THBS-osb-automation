package test;

public class MainClass 
{
	public static void main(String[] args) 
	{
		compareResponse_MI_POST(null);
	}
	public static void compareResponse_MI_POST(String title )
	{
		boolean status = true;
		String Exp_title = "Ms";
		if (!((title == null || title.equals("Ms"))||(title == null && Exp_title == null)))
				{
					System.out.println("title returned is invalid");
					status = false;
				}
		else 
		{
			System.out.println("title returned is valid");
		}
		
	}
}
