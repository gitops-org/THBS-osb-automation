package test;

import java.io.BufferedReader;
import java.io.FileReader;


public class Class1
{
	public static void main(String[] args)
	{
		FileReader fr;
		double count = 0;
		try 
		{
			//fr = new FileReader("C:\\Users\\Apoorva_Rangaraj\\Desktop\\MI Login logs.txt");
			
			fr = new FileReader("D:\\Apoorva\\Pure Energy\\RRL\\putty logs\\TEST_ESB1.txt");
			BufferedReader br = new BufferedReader(fr);
			String inputSearch = "postMemberIdentityEmailLoginJanrainVerifyMemberIdentityResponse";
			String line = "";
			StringBuilder sb = new StringBuilder();
			String afterReplacement = null;
			while ((line = br.readLine()) != null) 
			{
				//System.out.println(br.readLine());
				String[] words = line.split(" ");

				for (String word : words) {
					if (word.equals(inputSearch)) 
					{
						System.out.println();
						count++;
						if (count >= 1) 
						{
							sb.append(line);
							sb.append("\n");
							System.out.println(sb.toString());
							//System.out.println("length of sb: "+sb.length());
							String[] v1 = sb.toString().split(",");
							
							String[] v2 = v1[6].split(":");
							System.out.println(""+v2[1]);
							line = br.readLine();
							afterReplacement = v2[1].replace("\"", "");
							System.out.println("afterReplacement:"+afterReplacement);
							sb.delete(0, sb.length());
							//System.out.println("sb after deleting: "+sb.toString()+":");
							
						}
					}
					
				}
			}
			System.out.println("outside loop: "+afterReplacement);

			fr.close();
		}
		catch (Exception e1) 
		{
			e1.printStackTrace();
		}

	}
}