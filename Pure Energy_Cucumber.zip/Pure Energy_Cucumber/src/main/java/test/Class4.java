package test;

import java.io.InputStream;
import java.util.Properties;

public class Class4 
{

	public static void main(String[] args) throws Exception 
	{

		InputStream is = null;

		Properties prop = new Properties();
		is = prop.getClass().getResourceAsStream("/prop.properties");
		prop.load(is);
		System.out.println(prop.getProperty("Expected_Response"));

	}
}
