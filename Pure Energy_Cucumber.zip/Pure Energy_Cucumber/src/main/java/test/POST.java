package test;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class POST 
{
	
	public static RequestSpecification constructJsonRequest(String firstName, String lastName, String email)
	{
		JSONObject requestParams = new JSONObject();
		/*requestParams.put("firstName", firstName);
		requestParams.put("lastName", lastName);
		requestParams.put("email", email);*/
		RequestSpecification request = RestAssured.given();
		request.body(requestParams.toJSONString()).log();
		request.log();
		System.out.println(request);
		return request;
		
	}
	
	
	@Test
	public void RegistrationSuccessful()
	{		
		//RestAssured.baseURI ="https://52.213.194.179:8243/v1/member-identities/";
		RequestSpecification req = POST.constructJsonRequest("firstName", "lastName", "email@domain.com");	
		//Response response = req.post("/register");
	 
		/*int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, "201");
		String successCode = response.jsonPath().get("SuccessCode");
		Assert.assertEquals( "Correct Success code was returned", successCode, "OPERATION_SUCCESS");*/
	}
}
