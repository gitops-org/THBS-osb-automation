package test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.simple.JSONObject;
import com.github.kvnxiao.jsonequals.JsonCompareResult;
import com.github.kvnxiao.jsonequals.JsonRoot;

public class Class3 
{
	@SuppressWarnings("unchecked")
	public static void main(String[] args) 
	{

		Set<String> ignoreList = new HashSet<String>();
		ignoreList.add("$.timestamp");

		JSONObject jsonRootA = new JSONObject();
		jsonRootA.put("name","JohnSmith");
		jsonRootA.put("timestamp", 12345);		
		jsonRootA.put("resp", 1);

		JSONObject jsonRootB = new JSONObject();
		jsonRootB.put("name","JohnSmith");
		//jsonRootB.put("timestamp", 23456);
		jsonRootB.put("resp", 2);

		JsonRoot a = JsonRoot.from(jsonRootA.toJSONString());		
		JsonRoot b = JsonRoot.from(jsonRootB.toJSONString());

		JsonCompareResult result = a.compareToWithIgnore(b, ignoreList);
		
		List<String> msgs = result.getSuccessMessages();
		List<String> msgs1 = result.getInequalityMessages();
		
		System.out.println(msgs);
		System.out.println(msgs1);
		
		boolean equal = result.isEqual();
		
		if (equal) 
		{
			System.out.println("response is compared");
		} else {
			System.out.println("response verification error");
		}
		
		
		

	}


}
